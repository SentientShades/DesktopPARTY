(() => {
  const ICE = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'turn:openrelay.metered.ca:80',  username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turn:openrelay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' }
    ]
  };

  const SEND_MS = 33;
  const SMOOTHING = 0.25;
  const COLORS = ['#23d18b','#3a8ef0','#ffd24a','#e0508c','#9b6cf0','#22c8c8','#f06a3a','#c0c0c0'];

  let myId = null;
  let myProfile = { userId: '', displayName: '', avatar: '', accent: '', characterImage: '' };
  let myActivity = '';
  let inParty = false;
  let settings = {
    showNames: true,
    allowRemoteClicks: false,
    allowDrawing: true,
    sendMyClicks: false
  };

  const peers = new Map();
  const profiles = new Map();
  const accents = new Map();
  const activities = new Map();
  const externalHandlers = [];
  const inviteRetries = new Map();

  const layer   = document.getElementById('cursor-layer');
  const localEl = document.getElementById('cursor-local');

  function hashColor(id) {
    let h = 0;
    for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    return COLORS[h % COLORS.length];
  }

  function colorFor(id) {
    if (!id) return COLORS[0];
    if (id === myId && myProfile.accent) return myProfile.accent;
    return accents.get(id) || hashColor(id);
  }

  function applyRootAccent() {
    if (!myId) return;
    document.documentElement.style.setProperty('--green', colorFor(myId));
  }

  const nameOf = (id) => profiles.get(id)?.displayName || id;

  function applySettings() {
    document.body.classList.toggle('hide-names', !settings.showNames);
  }

  function makeCursorEl(userId) {
    const el = document.createElement('div');
    el.className = 'cursor remote';
    el.style.setProperty('--cursor-color', colorFor(userId));
    el.innerHTML =
      '<svg viewBox="0 0 16 16"><path d="M1 1l5 13 2-5 5-2z"/></svg>' +
      '<span class="cursor-label"></span>';
    el.querySelector('.cursor-label').textContent = userId;
    layer.appendChild(el);
    return el;
  }

  function ripple(x, y, color) {
    const dot = document.createElement('div');
    dot.className = 'click-ripple';
    dot.style.setProperty('--cursor-color', color);
    dot.style.left = `${x * window.innerWidth}px`;
    dot.style.top  = `${y * window.innerHeight}px`;
    layer.appendChild(dot);
    setTimeout(() => dot.remove(), 500);
  }

  function createPeer(userId) {
    if (peers.has(userId)) return peers.get(userId);

    const pc = new RTCPeerConnection(ICE);
    const entry = {
      pc, channel: null, remoteSet: false, pending: [],
      el: makeCursorEl(userId),
      target: { x: .5, y: .5 }, pos: { x: .5, y: .5 }
    };
    peers.set(userId, entry);

    pc.onicecandidate = (e) => {
      if (e.candidate) {
        window.overlay.signal({ to: userId, type: 'candidate', candidate: e.candidate.toJSON() });
      }
    };

    pc.onconnectionstatechange = () => {
      console.log(`pc[${userId}]:`, pc.connectionState);
      if (pc.connectionState === 'failed') pc.restartIce();
      if (pc.connectionState === 'closed') removePeer(userId);
      renderPanel();
    };

    pc.ondatachannel = (e) => attachChannel(entry, userId, e.channel);
    return entry;
  }

  function attachChannel(entry, userId, dc) {
    entry.channel = dc;

    dc.onopen = () => {
      clearTimeout(inviteRetries.get(userId));
      inviteRetries.delete(userId);
      entry.el.style.opacity = 1;
      dc.send(JSON.stringify({
        t: 'p',
        displayName: myProfile.displayName,
        avatar: myProfile.avatar,
        accent: myProfile.accent,
        characterImage: myProfile.characterImage
      }));
      dc.send(JSON.stringify({ t: 'a', text: myActivity }));
      window.BrowserActivity?.onPeerReady(userId);
      window.PhysicsObjects?.onPeerReady(userId);
      renderPanel();
    };

    dc.onclose = () => { entry.el.style.opacity = 0; renderPanel(); };

    dc.onmessage = (e) => {
      let m;
      try { m = JSON.parse(e.data); } catch { return; }

      if (m.t === 'c') {
        entry.target.x = m.x;
        entry.target.y = m.y;
      }
      else if (m.t === 'k') {
        ripple(m.x, m.y, colorFor(userId));
        if (settings.allowRemoteClicks) window.overlay.remoteClick({ x: m.x, y: m.y });
      }
      else if (m.t === 'p') {
        profiles.set(userId, {
          displayName: m.displayName || userId,
          avatar: m.avatar || '',
          characterImage: m.characterImage || ''
        });
        if (m.accent) accents.set(userId, m.accent);
        else accents.delete(userId);

        entry.el.querySelector('.cursor-label').textContent = m.displayName || userId;
        entry.el.style.setProperty('--cursor-color', colorFor(userId));
        renderPanel();
      }
      else if (m.t === 'a') {
        activities.set(userId, m.text || '');
        window.Draw?.refresh();
      }
      else if (m.t === 'd' || m.t === 'dclear') {
        if (settings.allowDrawing) window.Draw?.apply(m);
      }
      else {
        externalHandlers.forEach(fn => fn(userId, m));
      }
    };
  }

  function removePeer(userId) {
    const entry = peers.get(userId);
    if (!entry) return;
    clearTimeout(inviteRetries.get(userId));
    inviteRetries.delete(userId);
    entry.channel?.close();
    entry.pc.close();
    entry.el.remove();
    peers.delete(userId);
    profiles.delete(userId);
    accents.delete(userId);
    activities.delete(userId);
    renderPanel();
  }

  async function flush(entry) {
    entry.remoteSet = true;
    for (const c of entry.pending.splice(0)) {
      try { await entry.pc.addIceCandidate(c); } catch (e) { console.warn(e); }
    }
  }

  async function invite(userId, attempt = 1) {
    const existing = peers.get(userId);
    if (existing?.channel?.readyState === 'open') return;
    if (existing) removePeer(userId);

    const entry = createPeer(userId);
    attachChannel(entry, userId, entry.pc.createDataChannel('cursor', {
      ordered: false, maxRetransmits: 0
    }));
    const offer = await entry.pc.createOffer();
    await entry.pc.setLocalDescription(offer);
    window.overlay.signal({ to: userId, type: 'offer', sdp: { type: offer.type, sdp: offer.sdp } });

    clearTimeout(inviteRetries.get(userId));
    if (attempt < 4) {
      inviteRetries.set(userId, setTimeout(() => {
        const p = peers.get(userId);
        if (p?.channel?.readyState === 'open') return;
        console.log(`[peer] retrying invite to ${userId} (attempt ${attempt + 1})`);
        invite(userId, attempt + 1);
      }, 5000));
    }
  }

  function broadcast(payload) {
    const s = JSON.stringify(payload);
    peers.forEach(e => { if (e.channel?.readyState === 'open') e.channel.send(s); });
  }

  function sendTo(id, payload) {
    const e = peers.get(id);
    if (e?.channel?.readyState === 'open') e.channel.send(JSON.stringify(payload));
  }

  function onMessage(fn) { externalHandlers.push(fn); }

  function renderPanel() {
    window.Draw?.setDockVisible(inParty);
    if (!inParty || !myId) return;

    const ids = [...peers.keys()].sort();

    document.getElementById('party-panel-count').textContent = `${ids.length + 1}/8`;
    document.getElementById('pp-names').textContent =
      ids.length ? ids.map(nameOf).join(', ') : 'Just you';

    const avatarEl = document.getElementById('pp-avatar');
    if (myProfile.avatar) avatarEl.src = myProfile.avatar;

    const stack = document.getElementById('pp-stack');
    stack.innerHTML = '';
    ids.slice(0, 5).forEach(id => {
      const face = document.createElement('div');
      const open = peers.get(id)?.channel?.readyState === 'open';
      face.className = `pp-face${open ? '' : ' pending'}`;
      face.style.setProperty('--face-color', colorFor(id));
      const av = profiles.get(id)?.avatar;
      if (av) face.style.backgroundImage = `url('${av}')`;
      stack.appendChild(face);
    });

    window.Draw?.refresh();
  }

  window.overlay.onSignal(async (msg) => {
    const from = msg.from;
    try {
      if (msg.type === 'offer') {
        if (!msg.sdp?.sdp) return;
        const ex = peers.get(from);
        if (ex && ['connected', 'connecting'].includes(ex.pc.connectionState)) return;

        const entry = createPeer(from);
        await entry.pc.setRemoteDescription(msg.sdp);
        await flush(entry);
        const answer = await entry.pc.createAnswer();
        await entry.pc.setLocalDescription(answer);
        window.overlay.signal({ to: from, type: 'answer', sdp: { type: answer.type, sdp: answer.sdp } });
      }
      else if (msg.type === 'answer') {
        const entry = peers.get(from);
        if (!entry || !msg.sdp?.sdp) return;
        await entry.pc.setRemoteDescription(msg.sdp);
        await flush(entry);
      }
      else if (msg.type === 'candidate') {
        if (!msg.candidate?.candidate) return;
        const entry = peers.get(from);
        if (!entry) return;
        if (!entry.remoteSet) { entry.pending.push(msg.candidate); return; }
        await entry.pc.addIceCandidate(msg.candidate);
      }
    } catch (e) {
      console.warn('signal failed:', msg.type, e);
    }
  });

  window.overlay.onIdentity(({ userId }) => {
    myId = userId;
    localEl.style.setProperty('--cursor-color', colorFor(myId));
    applyRootAccent();
    renderPanel();
  });

  window.overlay.onProfile((p) => {
    myProfile = p;
    const el = document.getElementById('pp-avatar');
    if (el && p.avatar) el.src = p.avatar;
    localEl.style.setProperty('--cursor-color', colorFor(myId));
    applyRootAccent();
    broadcast({
      t: 'p',
      displayName: p.displayName,
      avatar: p.avatar,
      accent: p.accent,
      characterImage: p.characterImage
    });
    renderPanel();
  });

  window.overlay.onActivity((a) => {
    myActivity = a.details ? `${a.app} — ${a.details}` : a.app;
    broadcast({ t: 'a', text: myActivity });
    window.Draw?.refresh();
  });

  window.overlay.onSettings((s) => {
    settings = { ...settings, ...s };
    applySettings();
  });

  window.overlay.onRoster(({ myId: me, partyId, members }) => {
    if (me) myId = me;
    inParty = !!partyId;

    const list = (members || []).filter(id => id !== myId);

    peers.forEach((_, id) => { if (!list.includes(id)) removePeer(id); });

    if (inParty) {
      list.forEach(id => {
        if (peers.get(id)?.channel?.readyState === 'open') return;
        if (myId < id) invite(id);
      });
    } else {
      window.Draw?.clearCanvas();
    }

    applyRootAccent();
    renderPanel();
  });

  let lastSent = 0;
  window.overlay.onLocalCursor((p) => {
    localEl.style.transform = `translate(${p.x * window.innerWidth}px, ${p.y * window.innerHeight}px)`;
    const now = performance.now();
    if (now - lastSent < SEND_MS) return;
    lastSent = now;
    broadcast({ t: 'c', x: p.x, y: p.y });
  });

  window.overlay.onLocalClick((p) => broadcast({ t: 'k', x: p.x, y: p.y }));

  function tick() {
    peers.forEach(e => {
      e.pos.x += (e.target.x - e.pos.x) * SMOOTHING;
      e.pos.y += (e.target.y - e.pos.y) * SMOOTHING;
      e.el.style.transform = `translate(${e.pos.x * window.innerWidth}px, ${e.pos.y * window.innerHeight}px)`;
    });
    requestAnimationFrame(tick);
  }
  tick();
  applySettings();

  window.Party = {
    broadcast,
    sendTo,
    onMessage,
    peers,
    colorFor,
    myId: () => myId,
    infoFor(id) {
      if (id === myId) {
        return {
          name: myProfile.displayName || myId,
          avatar: myProfile.avatar,
          characterImage: myProfile.characterImage,
          activity: myActivity,
          state: ''
        };
      }
      const p = profiles.get(id) || {};
      return {
        name: p.displayName || id,
        avatar: p.avatar || '',
        characterImage: p.characterImage || '',
        activity: activities.get(id) || '',
        state: peers.get(id)?.channel?.readyState === 'open' ? '' : 'connecting…'
      };
    }
  };

  window.Cursors = { invite, peers };
})();