let winmod = null;
try { winmod = require('get-windows'); }
catch {
  try { winmod = require('active-win'); }
  catch { console.log('[activity] no window module — app detection off'); }
}

const KNOWN = {
  'chrome.exe': 'Chrome',
  'msedge.exe': 'Edge',
  'firefox.exe': 'Firefox',
  'Code.exe': 'VS Code',
  'devenv.exe': 'Visual Studio',
  'explorer.exe': 'File Explorer',
  'Spotify.exe': 'Spotify',
  'Discord.exe': 'Discord',
  'steam.exe': 'Steam',
  'javaw.exe': 'Minecraft',
  'RobloxPlayerBeta.exe': 'Roblox',
  'VALORANT-Win64-Shipping.exe': 'VALORANT',
  'League of Legends.exe': 'League of Legends',
  'DesktopFriends.exe': 'DesktopFriends'
};

let timer = null;
let last = '';

function friendly(owner) {
  const exe = owner?.name || '';
  return KNOWN[exe] || exe.replace(/\.exe$/i, '') || 'Unknown';
}

async function poll(onChange) {
  if (!winmod) return;
  try {
    const fn = winmod.activeWindow || winmod.default || winmod;
    const w = await fn();
    if (!w) return;

    const app = friendly(w.owner);
    const title = (w.title || '').slice(0, 60);

    const key = `${app}|${title}`;
    if (key === last) return;
    last = key;

    onChange({ app, details: title });
  } catch {}
}

function start(onChange, intervalMs = 3000) {
  if (timer) return;
  timer = setInterval(() => poll(onChange), intervalMs);
  poll(onChange);
}

function stop() {
  clearInterval(timer);
  timer = null;
  last = '';
}

const available = () => !!winmod;

module.exports = { start, stop, available };