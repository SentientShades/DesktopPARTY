(() => {
  const canvas = document.getElementById('draw-canvas');
  const ctx = canvas.getContext('2d');

  const dock       = document.getElementById('party-dock');
  const panel      = document.getElementById('party-panel');
  const drop       = document.getElementById('party-drop');
  const members    = document.getElementById('pd-members');
  const hint       = document.getElementById('pd-hint');
  const hueInput   = document.getElementById('hue');
  const lightInput = document.getElementById('light');
  const sizeInput  = document.getElementById('size');
  const sizeVal    = document.getElementById('size-val');
  const customSw   = document.getElementById('custom-swatch');

  const ERASE_W = 28;
  const BATCH_MS = 40;

  let tool = null;
  let brush = 4;
  let drawing = false;
  let openPanel = false;
  let lastPt = null;
  const pending = [];
  let flushTimer = null;

  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    let snap = null;
    try { snap = ctx.getImageData(0, 0, canvas.width, canvas.height); } catch {}
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    if (snap) { try { ctx.putImageData(snap, 0, 0); } catch {} }
  });

  function hslToHex(h, s, l) {
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60)       { r = c; g = x; }
    else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; }
    else              { r = c; b = x; }
    const to = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0');
    return `#${to(r)}${to(g)}${to(b)}`;
  }

  function refreshColour() {
    const h = Number(hueInput.value);
    const l = Number(lightInput.value) / 100;
    const hex = hslToHex(h, 0.85, l);

    customSw.style.setProperty('--sw', hex);
    customSw.dataset.color = hex;
    hueInput.style.setProperty('--thumb', hex);
    lightInput.style.setProperty('--thumb', hex);
    lightInput.style.background =
      `linear-gradient(to right, #000000, ${hslToHex(h, .85, .5)}, #ffffff)`;

    return hex;
  }

  [hueInput, lightInput].forEach(el => {
    el.addEventListener('input', () => {
      const hex = refreshColour();
      if (tool && tool !== 'erase') setTool(hex);
    });
  });

  sizeInput.addEventListener('input', () => {
    brush = Number(sizeInput.value);
    sizeVal.textContent = brush;
  });

  [hueInput, lightInput, sizeInput].forEach(el => {
    el.addEventListener('click', (e) => e.stopPropagation());
    el.addEventListener('pointerdown', (e) => e.stopPropagation());
  });

  function stroke(x1, y1, x2, y2, colour, width) {
    ctx.save();
    if (colour === null) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = colour;
    }
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(x1 * canvas.width, y1 * canvas.height);
    ctx.lineTo(x2 * canvas.width, y2 * canvas.height);
    ctx.stroke();
    ctx.restore();
  }

  function flush() {
    flushTimer = null;
    if (!pending.length) return;
    window.Party?.broadcast({ t: 'd', segs: pending.splice(0) });
  }

  function queue(seg) {
    pending.push(seg);
    if (!flushTimer) flushTimer = setTimeout(flush, BATCH_MS);
  }

  const toNorm = (e) => ({
    x: e.clientX / window.innerWidth,
    y: e.clientY / window.innerHeight
  });

  const currentColour = () => (tool === 'erase' ? null : tool);
  const currentWidth  = () => (tool === 'erase' ? ERASE_W : brush);

  canvas.addEventListener('pointerdown', (e) => {
    if (!tool) return;
    drawing = true;
    lastPt = toNorm(e);
    try { canvas.setPointerCapture(e.pointerId); } catch {}

    const c = currentColour(), w = currentWidth();
    stroke(lastPt.x, lastPt.y, lastPt.x, lastPt.y, c, w);
    queue([lastPt.x, lastPt.y, lastPt.x, lastPt.y, c, w]);
  });

  canvas.addEventListener('pointermove', (e) => {
    if (!drawing || !tool) return;
    const p = toNorm(e);
    const c = currentColour(), w = currentWidth();
    stroke(lastPt.x, lastPt.y, p.x, p.y, c, w);
    queue([lastPt.x, lastPt.y, p.x, p.y, c, w]);
    lastPt = p;
  });

  const endStroke = () => {
    if (!drawing) return;
    drawing = false;
    lastPt = null;
    flush();
    // matter can't sample the canvas, so ink terrain is rebuilt on demand
    window.PhysicsObjects?.rebuildInkTerrain?.();
  };
  canvas.addEventListener('pointerup', endStroke);
  canvas.addEventListener('pointercancel', endStroke);
  canvas.addEventListener('pointerleave', endStroke);

  function setTool(next) {
    tool = next;
    window.__drawMode = !!next;

    customSw.classList.toggle('active', !!next && next !== 'erase');
    document.querySelector('.eraser')?.classList.toggle('active', next === 'erase');

    canvas.classList.toggle('armed', !!next);
    window.overlay.drawMode(!!next);

    hint.textContent = next
      ? 'Drawing — press Esc to stop'
      : 'Pick the pen to draw anywhere on screen';
  }

  customSw.addEventListener('click', (e) => {
    e.stopPropagation();
    const hex = refreshColour();
    setTool(tool && tool !== 'erase' ? null : hex);
  });

  document.querySelectorAll('.tool[data-tool]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();

      if (btn.dataset.tool === 'clear') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        window.Party?.broadcast({ t: 'dclear' });
        window.PhysicsObjects?.rebuildInkTerrain?.();
        return;
      }

      setTool(tool === 'erase' ? null : 'erase');
    });
  });

  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (tool) setTool(null);
    else setPanel(false);
  });

  function setPanel(open) {
    openPanel = open;
    drop.classList.toggle('hidden', !open);
    if (!open && tool) setTool(null);
    if (open) renderMembers();
  }

  panel.addEventListener('click', () => setPanel(!openPanel));
  drop.addEventListener('click', (e) => e.stopPropagation());

  function renderMembers() {
    if (window.__spawnDragging) return;

    const P = window.Party;
    if (!P) return;

    members.innerHTML = '';
    const ids = [...P.peers.keys()].sort();
    const rows = [{ id: P.myId(), me: true }, ...ids.map(id => ({ id, me: false }))];

    if (rows.length === 1) {
      const empty = document.createElement('p');
      empty.className = 'pd-empty';
      empty.textContent = 'No one else here yet';
      members.appendChild(empty);
    }

    rows.forEach(({ id, me }) => {
      if (!id) return;
      const info = P.infoFor(id);

      const row = document.createElement('div');
      row.className = 'pd-row' + (me ? ' pd-row-me' : '');
      if (me) row.id = 'pd-row-me';

      const av = document.createElement('span');
      av.className = 'pd-av';
      av.style.setProperty('--sw', P.colorFor(id));
      if (info.avatar) av.style.backgroundImage = `url('${info.avatar}')`;

      const txt = document.createElement('span');
      txt.className = 'pd-text';

      const name = document.createElement('span');
      name.className = 'pd-name';
      name.textContent = info.name + (me ? ' (you — drag me!)' : '');

      const act = document.createElement('span');
      act.className = 'pd-act';
      act.textContent = info.activity || info.state;

      txt.append(name, act);
      row.append(av, txt);
      members.appendChild(row);
    });

    document.dispatchEvent(new CustomEvent('pd:rendered'));
  }

  refreshColour();
  sizeVal.textContent = brush;

  window.Draw = {
    apply(msg) {
      if (msg.t === 'dclear') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        window.PhysicsObjects?.rebuildInkTerrain?.();
        return;
      }
      (msg.segs || []).forEach(([x1, y1, x2, y2, colour, width]) => {
        stroke(x1, y1, x2, y2, colour, width);
      });
      window.PhysicsObjects?.rebuildInkTerrain?.();
    },
    clearCanvas() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      window.PhysicsObjects?.rebuildInkTerrain?.();
    },
    isInk(px, py) {
      if (px < 0 || py < 0 || px >= canvas.width || py >= canvas.height) return false;
      try {
        return ctx.getImageData(px, py, 1, 1).data[3] > 10;
      } catch { return false; }
    },
    refresh() { if (openPanel) renderMembers(); },
    setDockVisible(v) {
      dock.classList.toggle('hidden', !v);
      if (!v) {
        setPanel(false);
        if (tool) setTool(null);
      }
    }
  };
})();