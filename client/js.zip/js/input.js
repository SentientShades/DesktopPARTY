let uiohook = null;
let nut = null;

try { uiohook = require('uiohook-napi'); }
catch { console.log('uiohook-napi not installed — click sending unavailable'); }

try { nut = require('@nut-tree-fork/nut-js'); }
catch { console.log('nut-js not installed — remote click injection unavailable'); }

const available = { send: !!uiohook, receive: !!nut };
let started = false;

function startClickCapture(onClick) {
  if (!uiohook || started) return false;
  started = true;
  uiohook.uIOhook.on('mousedown', (e) => onClick({ rawX: e.x, rawY: e.y }));
  uiohook.uIOhook.start();
  return true;
}

function stopClickCapture() {
  if (!uiohook || !started) return;
  try { uiohook.uIOhook.stop(); } catch {}
  started = false;
}

async function injectClick(x, y) {
  if (!nut) return false;
  try {
    const { mouse, Point, Button } = nut;
    mouse.config.mouseSpeed = 5000;
    await mouse.setPosition(new Point(Math.round(x), Math.round(y)));
    await mouse.click(Button.LEFT);
    return true;
  } catch (e) {
    console.warn('injectClick failed:', e.message);
    return false;
  }
}

module.exports = { available, startClickCapture, stopClickCapture, injectClick };