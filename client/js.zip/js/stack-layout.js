(() => {
  const RIGHT_MARGIN = 18;
  const GAP = 10;
  const DOCK_BOTTOM = 18;

  const zones = [];

  function register(el, opts = {}) {
    zones.push({ el, order: opts.order ?? zones.length });
    zones.sort((a, b) => a.order - b.order);
  }

  function isVisible(el) {
    return el && !el.classList.contains('hidden') && el.offsetParent !== null;
  }

  function layout() {
    const dock = document.getElementById('party-dock');
    const dockHeight = isVisible(dock) ? dock.offsetHeight : 0;

    let bottom = DOCK_BOTTOM + dockHeight + (dockHeight ? GAP : 0);
    zones.forEach(({ el }) => {
      if (!isVisible(el)) return;
      el.style.right = `${RIGHT_MARGIN}px`;
      el.style.bottom = `${bottom}px`;
      bottom += el.offsetHeight + GAP;
    });
  }

  const mo = new MutationObserver(layout);
  mo.observe(document.body, { attributes: true, attributeFilter: ['class', 'style'], subtree: true });

  window.addEventListener('resize', layout);
  setInterval(layout, 400);

  window.StackLayout = { register, layout };
})();