(() => {
  const { Engine, Bodies, Body, Composite, Constraint, Sleeping, Events } = Matter;

  const BROADCAST_MS = 50;
  const THROW_WINDOW_MS = 120;
  const THROW_MAX_SPEED = 48;
  const MAX_OBJECTS = 440;
  const AUTHORITY_MS = 4000;
  const WALL_THICK = 200;

  const DRAG_STIFFNESS = 0.16;
  const DRAG_DAMPING = 0.3;

  // ── global bounce dial ──
  // 0 = dead thud, 0.35 = lively, 0.6 = rubber, 0.85+ = superball.
  // Past ~0.7 stacks stop settling, since bodies never lose enough energy.
  const BOUNCINESS = 0.75;

  // player tuning — acceleration based, no snapping
  const MOVE_FORCE = 0.0042;
  const MAX_RUN_SPEED = 8.5;
  const AIR_CONTROL = 0.4;
  const JUMP_IMPULSE = 0.16;
  const GROUND_FRICTION_BRAKE = 0.06;

  const UPRIGHT_TORQUE = 0.512;
  const UPRIGHT_DAMP = 0.156;
  const UPRIGHT_AIR_SCALE = 0.25;
  const KNOCK_THRESHOLD = 7;

  const GROUND_GRACE_MS = 110;
  const INK_CELL = 16;

  const layer = document.createElement('div');
  layer.id = 'object-world';
  document.body.appendChild(layer);

  const engine = Engine.create({
    gravity: { x: 0, y: 2.6 },
    enableSleeping: true
  });
  engine.positionIterations = 10;
  engine.velocityIterations = 8;

  const objects = new Map();
  const playerByBody = new Map();
  let myId = null;
  let seq = 0;

  const SHAPES = {
    box:      { w: 46, h: 46 },
    ball:     { w: 44, h: 44 },
    crate:    { w: 66, h: 40 },
    triangle: { w: 50, h: 46 }
  };

  const uid = () => `${myId || 'x'}-${Date.now().toString(36)}-${(seq++).toString(36)}`;

  // ---------- static world ----------
  let walls = [];
  function buildWalls() {
    if (walls.length) Composite.remove(engine.world, walls);
    const W = window.innerWidth, H = window.innerHeight;
    const opts = { isStatic: true, friction: 1.0, restitution: BOUNCINESS, label: 'wall' };

    walls = [
      Bodies.rectangle(W / 2, H + WALL_THICK / 2, W * 3, WALL_THICK, opts),
      Bodies.rectangle(W / 2, -WALL_THICK / 2, W * 3, WALL_THICK, opts),
      Bodies.rectangle(-WALL_THICK / 2, H / 2, WALL_THICK, H * 3, opts),
      Bodies.rectangle(W + WALL_THICK / 2, H / 2, WALL_THICK, H * 3, opts)
    ];
    Composite.add(engine.world, walls);
  }
  buildWalls();
  window.addEventListener('resize', buildWalls);

  // ---------- ink terrain ----------
  let inkBodies = [];
  let inkRebuildQueued = false;

  function rebuildInkTerrain() {
    if (!window.Draw?.isInk) return;

    if (inkBodies.length) {
      Composite.remove(engine.world, inkBodies);
      inkBodies = [];
    }

    const W = window.innerWidth, H = window.innerHeight;
    const opts = { isStatic: true, friction: 1.0, restitution: BOUNCINESS, label: 'ink' };

    for (let y = 0; y < H; y += INK_CELL) {
      let runStart = -1;
      for (let x = 0; x <= W; x += INK_CELL) {
        const solid = x < W && window.Draw.isInk(x + INK_CELL / 2, y + INK_CELL / 2);
        if (solid && runStart < 0) runStart = x;
        if ((!solid || x >= W) && runStart >= 0) {
          const width = x - runStart;
          inkBodies.push(Bodies.rectangle(
            runStart + width / 2, y + INK_CELL / 2, width, INK_CELL, opts
          ));
          runStart = -1;
        }
      }
    }
    if (inkBodies.length) Composite.add(engine.world, inkBodies);
    objects.forEach(o => Sleeping.set(o.body, false));
  }

  function queueInkRebuild() {
    if (inkRebuildQueued) return;
    inkRebuildQueued = true;
    setTimeout(() => { inkRebuildQueued = false; rebuildInkTerrain(); }, 180);
  }

  // ---------- grounded tracking ----------
  function noteContact(bodyA, bodyB) {
    const check = (self, other) => {
      const p = playerByBody.get(self);
      if (!p) return;
      if (other.position.y > self.position.y + p.hh * 0.35) {
        p.lastGroundedAt = performance.now();
      }
      p.lastTouchAt = performance.now();
    };
    check(bodyA, bodyB);
    check(bodyB, bodyA);
  }

  Events.on(engine, 'collisionStart', (e) => {
    for (const pair of e.pairs) noteContact(pair.bodyA, pair.bodyB);
  });
  Events.on(engine, 'collisionActive', (e) => {
    for (const pair of e.pairs) noteContact(pair.bodyA, pair.bodyB);
  });

  const isGrounded = (p) => performance.now() - (p.lastGroundedAt || 0) < GROUND_GRACE_MS;
  const isTouching = (p) => performance.now() - (p.lastTouchAt || 0) < GROUND_GRACE_MS;

  // ---------- objects ----------
  function makeObject(id, shape, color, ownerId, x, y) {
    const spec = SHAPES[shape] || SHAPES.box;

    const el = document.createElement('div');
    el.className = `phys-obj phys-${shape} interactive`;
    el.style.width = spec.w + 'px';
    el.style.height = spec.h + 'px';
    el.style.setProperty('--obj-color', color);
    layer.appendChild(el);

    const opts = {
      friction: 0.75,
      frictionStatic: 1.1,
      frictionAir: 0.006,
      restitution: BOUNCINESS,
      density: 0.0022,
      sleepThreshold: 40,
      label: 'obj'
    };

    let body;
    if (shape === 'ball') body = Bodies.circle(x, y, spec.w / 2, opts);
    else if (shape === 'triangle') body = Bodies.polygon(x, y, 3, spec.w / 2, opts);
    else body = Bodies.rectangle(x, y, spec.w, spec.h, opts);

    Composite.add(engine.world, body);

    const o = {
      id, el, body, shape, color, ownerId,
      hw: spec.w / 2, hh: spec.h / 2,
      authorityUntil: 0,
      dragging: false,
      constraint: null,
      history: []
    };

    Object.defineProperty(o, 'owner', { get() { return this.ownerId === myId; } });

    objects.set(id, o);
    bindDrag(o);
    renderObject(o);
    window.Players?.updateHasPlayers?.();
    return o;
  }

  function recoverIfLost(body) {
    if (!body) return;
    const p = body.position;
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) ||
        p.y > window.innerHeight + 2000 || p.y < -2000 ||
        p.x > window.innerWidth + 2000 || p.x < -2000) {
      Body.setPosition(body, { x: window.innerWidth / 2, y: 100 });
      Body.setVelocity(body, { x: 0, y: 0 });
      Body.setAngularVelocity(body, 0);
    }
  }

  function renderObject(o) {
    recoverIfLost(o.body);
    o.el.style.transform =
      `translate(${(o.body.position.x - o.hw).toFixed(1)}px, ${(o.body.position.y - o.hh).toFixed(1)}px) ` +
      `rotate(${(o.body.angle * 180 / Math.PI).toFixed(2)}deg)`;
  }

  function removeObject(id, silent) {
    const o = objects.get(id);
    if (!o) return;
    releaseConstraint(o);
    Composite.remove(engine.world, o.body);
    o.el.remove();
    objects.delete(id);
    window.Players?.updateHasPlayers?.();
    if (!silent && o.owner) window.Party.broadcast({ t: 'objDel', id });
  }

  function claim(o) {
    const wasOwner = o.owner;
    o.ownerId = myId;
    o.authorityUntil = performance.now() + AUTHORITY_MS;
    if (!wasOwner) window.Party.broadcast({ t: 'objClaim', id: o.id });
  }

  function releaseConstraint(entity) {
    if (!entity || !entity.constraint) return;
    Composite.remove(engine.world, entity.constraint);
    entity.constraint = null;
  }

  // ---------- player bodies ----------
  function attachPlayerBody(p, x, y) {
    const body = Bodies.rectangle(x, y, p.hw * 2, p.hh * 2, {
      friction: 0.7,
      frictionStatic: 1.0,
      frictionAir: 0.008,
      restitution: BOUNCINESS * 0.6,
      density: 0.0042,
      sleepThreshold: Infinity,
      label: 'player'
    });
    Composite.add(engine.world, body);
    p.body = body;
    p.lastGroundedAt = 0;
    p.lastTouchAt = 0;
    playerByBody.set(body, p);
    return body;
  }

  function detachPlayerBody(p) {
    releaseConstraint(p);
    if (p.body) {
      playerByBody.delete(p.body);
      Composite.remove(engine.world, p.body);
      p.body = null;
    }
  }

  function drivePlayer(p) {
    if (!p.body || !p.owner || p.dragging) return;

    const b = p.body;
    const keys = window.Players.keys;
    const grounded = isGrounded(p);

    let dir = 0;
    if (keys.a) dir -= 1;
    if (keys.d) dir += 1;

    if (dir !== 0) {
      // acceleration only — force tapers as 1-(v/vmax)² so it eases toward
      // top speed instead of snapping, and full force is kept when turning
      const speedRatio = Math.min(1, Math.abs(b.velocity.x) / MAX_RUN_SPEED);
      const sameDir = Math.sign(b.velocity.x) === dir;
      const taper = sameDir ? (1 - speedRatio * speedRatio) : 1;

      Body.applyForce(b, b.position, {
        x: dir * MOVE_FORCE * b.mass * taper * (grounded ? 1 : AIR_CONTROL),
        y: 0
      });
    } else if (grounded) {
      // light brake only, so momentum carries
      Body.applyForce(b, b.position, {
        x: -b.velocity.x * GROUND_FRICTION_BRAKE * b.mass * 0.01,
        y: 0
      });
    }

    // hold W and it jumps again the moment it can — consuming the ground
    // stamp prevents several impulses firing within one contact window
    if (keys.w && grounded) {
      Body.applyForce(b, b.position, { x: 0, y: -JUMP_IMPULSE * b.mass });
      p.lastGroundedAt = 0;
    }

    // upright stabilizer — always on, weaker midair, yields to hard impacts
    let err = b.angle;
    while (err > Math.PI) err -= Math.PI * 2;
    while (err < -Math.PI) err += Math.PI * 2;

    const impactSpeed = Math.hypot(b.velocity.x, b.velocity.y);
    const knockFactor = Math.max(0, 1 - impactSpeed / KNOCK_THRESHOLD);
    const scale = (grounded || isTouching(p)) ? 1 : UPRIGHT_AIR_SCALE;

    b.torque += (-err * UPRIGHT_TORQUE - b.angularVelocity * UPRIGHT_DAMP)
                * b.mass * scale * knockFactor;
  }

  function applyRemotePlayerState(p, m) {
    if (!p.body) return;
    Body.setPosition(p.body, {
      x: m.x * window.innerWidth,
      y: m.y * window.innerHeight
    });
    Body.setAngle(p.body, m.rot || 0);
    Body.setVelocity(p.body, { x: m.vx || 0, y: m.vy || 0 });
    Body.setAngularVelocity(p.body, m.w || 0);
  }

  // ---------- shared constraint drag ----------
  function startConstraintDrag(entity, clientX, clientY) {
    if (!entity.body) return;
    releaseConstraint(entity);

    const pos = entity.body.position;
    const dx = clientX - pos.x, dy = clientY - pos.y;
    const c = Math.cos(-entity.body.angle), s = Math.sin(-entity.body.angle);

    entity.constraint = Constraint.create({
      pointA: { x: clientX, y: clientY },
      bodyB: entity.body,
      pointB: { x: dx * c - dy * s, y: dx * s + dy * c },
      stiffness: DRAG_STIFFNESS,
      damping: DRAG_DAMPING,
      length: 0
    });
    Composite.add(engine.world, entity.constraint);

    Sleeping.set(entity.body, false);
    entity.dragging = true;
    entity.history = [{ x: clientX, y: clientY, t: performance.now() }];
    window.overlay.playerActive?.(true);
  }

  function moveConstraintDrag(entity, clientX, clientY) {
    if (!entity.constraint) return;
    entity.constraint.pointA = { x: clientX, y: clientY };
    const now = performance.now();
    entity.history.push({ x: clientX, y: clientY, t: now });
    while (entity.history.length > 1 && now - entity.history[0].t > THROW_WINDOW_MS) {
      entity.history.shift();
    }
  }

  function endConstraintDrag(entity, clientX, clientY) {
    releaseConstraint(entity);
    if (!entity.dragging) return null;
    entity.dragging = false;

    const t = performance.now();
    entity.history.push({ x: clientX, y: clientY, t });
    while (entity.history.length > 1 && t - entity.history[0].t > THROW_WINDOW_MS) {
      entity.history.shift();
    }

    if (entity.history.length >= 2 && entity.body) {
      const f = entity.history[0], l = entity.history[entity.history.length - 1];
      const dtt = (l.t - f.t) / 1000;
      if (dtt > 0.005) {
        let vx = ((l.x - f.x) / dtt) / 60;
        let vy = ((l.y - f.y) / dtt) / 60;
        const sp = Math.hypot(vx, vy);
        if (sp > THROW_MAX_SPEED) { vx *= THROW_MAX_SPEED / sp; vy *= THROW_MAX_SPEED / sp; }
        Body.setVelocity(entity.body, { x: vx, y: vy });
      } else {
        Body.setVelocity(entity.body, { x: 0, y: 0 });
      }
    }
    entity.history = [];
    return entity.body ? entity.body.velocity : null;
  }

  function bindPlayerDrag(p) {
    if (p.__dragBound) return;
    p.__dragBound = true;

    p.el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      e.preventDefault();
      startConstraintDrag(p, e.clientX, e.clientY);

      const onMove = (ev) => moveConstraintDrag(p, ev.clientX, ev.clientY);
      const onUp = (ev) => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);
        endConstraintDrag(p, ev.clientX, ev.clientY);
        window.Players.checkThrowKill(p, ev.clientX, ev.clientY);
      };

      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
    });
  }

  function bindDrag(o) {
    o.el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      e.preventDefault();
      claim(o);
      startConstraintDrag(o, e.clientX, e.clientY);
      window.Party.broadcast({ t: 'objGrab', id: o.id });

      const onMove = (ev) => moveConstraintDrag(o, ev.clientX, ev.clientY);
      const onUp = (ev) => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);

        const v = endConstraintDrag(o, ev.clientX, ev.clientY);
        if (v) {
          window.Party.broadcast({
            t: 'objRelease', id: o.id, vx: v.x, vy: v.y, w: o.body.angularVelocity
          });
        }
      };

      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
    });
  }

  function broadcastState(o) {
    const p = o.body.position, v = o.body.velocity;
    window.Party.broadcast({
      t: 'objState', id: o.id,
      x: p.x / window.innerWidth, y: p.y / window.innerHeight,
      rot: o.body.angle, vx: v.x, vy: v.y, w: o.body.angularVelocity
    });
  }

  // ---------- main loop ----------
  let lastBroadcast = 0;
  let lastTime = 0;

  function tick(now) {
    try {
      const dtMs = lastTime ? Math.min(33, now - lastTime) : 16.7;
      lastTime = now;

      objects.forEach(o => {
        if (o.owner && o.authorityUntil && now > o.authorityUntil && !o.dragging) {
          o.authorityUntil = 0;
        }
      });

      const players = window.Players?.getBodies?.() || [];
      players.forEach(p => drivePlayer(p));

      Engine.update(engine, dtMs);

      players.forEach(p => {
        recoverIfLost(p.body);
        window.Players.render(p);
      });
      objects.forEach(o => renderObject(o));

      if (now - lastBroadcast > BROADCAST_MS) {
        lastBroadcast = now;
        objects.forEach(o => {
          if (!o.owner || o.body.isSleeping) return;
          broadcastState(o);
        });
      }
    } catch (err) {
      console.error('[physics] frame error:', err);
    }

    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  // ---------- spawn / clear ----------
  function spawn(shape) {
    if (objects.size >= MAX_OBJECTS) return;
    const id = uid();
    const color = window.Party.colorFor(myId);
    const x = window.innerWidth / 2 + (Math.random() - 0.5) * 260;
    const y = 120;

    const o = makeObject(id, shape, color, myId, x, y);
    Body.setVelocity(o.body, { x: (Math.random() - 0.5) * 4, y: 0 });
    Body.setAngularVelocity(o.body, (Math.random() - 0.5) * 0.1);

    window.Party.broadcast({
      t: 'objNew', id, shape, color,
      x: x / window.innerWidth, y: y / window.innerHeight
    });
  }

  function clearMine() {
    [...objects.values()].filter(o => o.owner).forEach(o => removeObject(o.id));
  }

  document.querySelectorAll('[data-spawn]').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); spawn(btn.dataset.spawn); });
  });
  document.getElementById('obj-clear')?.addEventListener('click', (e) => {
    e.stopPropagation(); clearMine();
  });

  // ---------- networking ----------
  window.Party?.onMessage((fromId, m) => {
    if (m.t === 'objNew') {
      if (objects.has(m.id)) return;
      makeObject(m.id, m.shape, m.color, fromId,
        m.x * window.innerWidth, m.y * window.innerHeight);
    }
    else if (m.t === 'objClaim') {
      const o = objects.get(m.id);
      if (!o) return;
      o.ownerId = fromId;
      o.authorityUntil = 0;
    }
    else if (m.t === 'objState') {
      const o = objects.get(m.id);
      if (!o || o.dragging) return;
      if (o.owner && o.authorityUntil > performance.now()) return;
      o.ownerId = fromId;
      Sleeping.set(o.body, false);
      Body.setPosition(o.body, {
        x: m.x * window.innerWidth,
        y: m.y * window.innerHeight
      });
      Body.setAngle(o.body, m.rot);
      Body.setVelocity(o.body, { x: m.vx, y: m.vy });
      Body.setAngularVelocity(o.body, m.w);
      renderObject(o);
    }
    else if (m.t === 'objDel') removeObject(m.id, true);
    else if (m.t === 'objGrab') {
      const o = objects.get(m.id);
      if (!o) return;
      o.ownerId = fromId;
      Sleeping.set(o.body, false);
    }
    else if (m.t === 'objRelease') {
      const o = objects.get(m.id);
      if (!o || o.dragging) return;
      Sleeping.set(o.body, false);
      Body.setVelocity(o.body, { x: m.vx, y: m.vy });
      Body.setAngularVelocity(o.body, m.w);
    }
  });

  window.overlay.onIdentity(({ userId }) => { myId = userId; });

  window.overlay.onRoster(({ members }) => {
    const set = new Set(members || []);
    objects.forEach(o => {
      if (!set.has(o.ownerId) && o.ownerId !== myId) claim(o);
    });
  });

  window.PhysicsObjects = {
    count: () => objects.size,
    attachPlayerBody(p, x, y) {
      attachPlayerBody(p, x, y);
      bindPlayerDrag(p);
    },
    detachPlayerBody,
    beginPlayerDrag: startConstraintDrag,
    movePlayerDrag: moveConstraintDrag,
    endPlayerDrag(p, x, y) {
      endConstraintDrag(p, x, y);
      window.Players.checkThrowKill(p, x, y);
    },
    applyRemotePlayerState,
    onPeerReady(peerId) {
      objects.forEach(o => {
        if (!o.owner) return;
        const p = o.body.position;
        window.Party.sendTo(peerId, {
          t: 'objNew', id: o.id, shape: o.shape, color: o.color,
          x: p.x / window.innerWidth, y: p.y / window.innerHeight
        });
      });
    },
    clearMine,
    rebuildInkTerrain: queueInkRebuild
  };
})();