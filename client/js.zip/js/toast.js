(() => {
  const MAX_VISIBLE = 4;
  const DEFAULT_DURATION = 6000;
  const EXIT_MS = 220;

  const stack = document.getElementById('toast-stack');
  const queue = [];
  let visible = 0;

  function buildToast(opts) {
    const el = document.createElement('div');
    el.className = 'toast interactive entering';
    el.dataset.status = opts.status || 'online';

    const wrap = document.createElement('div');
    wrap.className = 'avatar-wrap';
    const img = document.createElement('img');
    img.className = 'avatar';
    img.src = opts.avatar || '../assets/pfp.jpg';
    img.alt = '';
    const dot = document.createElement('span');
    dot.className = 'status-dot';
    wrap.append(img, dot);

    const body = document.createElement('div');
    body.className = 'toast-body';
    const name = document.createElement('span');
    name.className = 'toast-name';
    name.textContent = opts.name || 'Unknown';
    const sub = document.createElement('span');
    sub.className = 'toast-sub';
    sub.textContent = opts.activity || '';
    body.append(name, sub);

    const art = document.createElement('div');
    art.className = 'toast-art';
    if (opts.art) art.style.setProperty('--art', `url('${opts.art}')`);

    const close = document.createElement('button');
    close.className = 'toast-close';
    close.setAttribute('aria-label', 'Dismiss');
    close.innerHTML =
      '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.2">' +
      '<path d="M3 3l10 10M13 3L3 13"/></svg>';

    el.append(wrap, body, art, close);
    return { el, close };
  }

  function showToast(opts = {}) {
    if (visible >= MAX_VISIBLE) {
      queue.push(opts);
      return null;
    }
    visible++;

    const { el, close } = buildToast(opts);
    stack.appendChild(el);

    void el.offsetWidth;
    el.classList.remove('entering');

    const duration = opts.duration ?? DEFAULT_DURATION;
    let timer = null;
    let remaining = duration;
    let startedAt = 0;

    const startTimer = () => {
      if (duration <= 0) return;
      startedAt = Date.now();
      timer = setTimeout(dismiss, remaining);
    };
    const pauseTimer = () => {
      if (!timer) return;
      clearTimeout(timer);
      timer = null;
      remaining -= Date.now() - startedAt;
    };

    let dismissed = false;
    function dismiss() {
      if (dismissed) return;
      dismissed = true;
      clearTimeout(timer);

      el.style.height = `${el.offsetHeight}px`;
      void el.offsetWidth;
      el.classList.add('leaving');

      setTimeout(() => {
        el.remove();
        visible--;
        if (queue.length) showToast(queue.shift());
      }, EXIT_MS);
    }

    el.addEventListener('mouseenter', pauseTimer);
    el.addEventListener('mouseleave', () => { startedAt = Date.now(); startTimer(); });
    close.addEventListener('click', (e) => { e.stopPropagation(); dismiss(); });

    if (opts.id) {
      el.style.cursor = 'pointer';
      el.addEventListener('click', () => {
        window.overlay?.onToastClick?.(opts.id);
        dismiss();
      });
    }

    startTimer();
    return { dismiss, el };
  }

  function clearAll() {
    queue.length = 0;
    stack.querySelectorAll('.toast').forEach(t => {
      t.querySelector('.toast-close')?.click();
    });
  }

  window.Toasts = { show: showToast, clearAll };

  window.overlay?.onToast?.(showToast);
})();