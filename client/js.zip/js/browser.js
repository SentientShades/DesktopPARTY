(() => {
  const CARD_W = 760;
  const CARD_H = 520;
  const MOVE_MS = 33;

  let card = null;
  let webview = null;
  let dragging = false;
  let dragOffset = { x: 0, y: 0 };
  let applyingRemoteNav = false;
  let lastMoveSent = 0;

  const activityBtn = document.getElementById('act-browser');

  function currentPos() {
    const r = card.getBoundingClientRect();
    return { x: r.left, y: r.top };
  }

  function setPos(x, y) {
    x = Math.max(0, Math.min(window.innerWidth - 60, x));
    y = Math.max(0, Math.min(window.innerHeight - 40, y));
    card.style.transform = `translate(${x}px, ${y}px)`;
  }

  function normalizeUrl(raw) {
    const u = raw.trim();
    if (/^https?:\/\//i.test(u)) return u;
    if (/^[\w-]+(\.[\w-]+)+([\/?#].*)?$/.test(u)) return `https://${u}`;
    return `https://www.google.com/search?q=${encodeURIComponent(u)}`;
  }

  async function buildCard(url, x, y) {
    const preloadUrl = await window.overlay.getWebviewPreloadPath();

    card = document.createElement('div');
    card.className = 'browser-card interactive';
    card.style.width = CARD_W + 'px';
    card.style.height = CARD_H + 'px';

    const bar = document.createElement('div');
    bar.className = 'browser-bar';

    const drag = document.createElement('div');
    drag.className = 'browser-drag';
    drag.textContent = '⠿';

    const addr = document.createElement('input');
    addr.type = 'text';
    addr.className = 'browser-addr';
    addr.value = url;
    addr.spellcheck = false;

    const go = document.createElement('button');
    go.className = 'browser-go mini';
    go.textContent = 'Go';

    const hide = document.createElement('button');
    hide.className = 'browser-hide mini ghost';
    hide.textContent = '–';
    hide.title = 'Hide for me';

    const closeAll = document.createElement('button');
    closeAll.className = 'browser-close mini ghost';
    closeAll.textContent = '✕';
    closeAll.title = 'End for everyone';

    bar.append(drag, addr, go, hide, closeAll);

    webview = document.createElement('webview');
    webview.className = 'browser-view';
    webview.setAttribute('src', url);
    webview.setAttribute('preload', preloadUrl);
    webview.setAttribute('allowpopups', 'false');
    webview.setAttribute('partition', 'persist:sharedbrowser');

    card.append(bar, webview);
    document.body.appendChild(card);
    setPos(x, y);

    function navigate(rawUrl) {
      webview.loadURL(normalizeUrl(rawUrl)).catch(() => {});
    }

    go.addEventListener('click', () => navigate(addr.value));
    addr.addEventListener('keydown', (e) => { if (e.key === 'Enter') navigate(addr.value); });
    addr.addEventListener('pointerdown', (e) => e.stopPropagation());
    go.addEventListener('pointerdown', (e) => e.stopPropagation());

    const onNav = (e) => {
      addr.value = e.url;
      if (!applyingRemoteNav) {
        window.Party.broadcast({ t: 'bwNav', url: e.url });
      }
    };
    webview.addEventListener('did-navigate', onNav);
    webview.addEventListener('did-navigate-in-page', onNav);

    webview.addEventListener('ipc-message', (e) => {
      if (e.channel === 'bw:scroll') {
        window.Party.broadcast({ t: 'bwScroll', x: e.args[0].x, y: e.args[0].y });
      } else if (e.channel === 'bw:selection') {
        window.Party.broadcast({ t: 'bwSel', sel: e.args[0] });
      } else if (e.channel === 'bw:video') {
        window.Party.broadcast({ t: 'bwVideo', ...e.args[0] });
      }
    });

    drag.addEventListener('pointerdown', (e) => {
      dragging = true;
      const pos = currentPos();
      dragOffset = { x: e.clientX - pos.x, y: e.clientY - pos.y };
      try { drag.setPointerCapture(e.pointerId); } catch {}
    });
    drag.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const x = e.clientX - dragOffset.x;
      const y = e.clientY - dragOffset.y;
      setPos(x, y);
      const now = performance.now();
      if (now - lastMoveSent > MOVE_MS) {
        lastMoveSent = now;
        window.Party.broadcast({ t: 'bwMove', x: x / window.innerWidth, y: y / window.innerHeight });
      }
    });
    const endDrag = () => {
      if (!dragging) return;
      dragging = false;
      const pos = currentPos();
      window.Party.broadcast({ t: 'bwMove', x: pos.x / window.innerWidth, y: pos.y / window.innerHeight });
    };
    drag.addEventListener('pointerup', endDrag);
    drag.addEventListener('pointercancel', endDrag);

    hide.addEventListener('click', () => destroy());
    closeAll.addEventListener('click', () => {
      window.Party.broadcast({ t: 'bwClose' });
      destroy();
    });
  }

  function destroy() {
    if (card) { card.remove(); card = null; webview = null; }
    updateActivityLabel();
  }

  function updateActivityLabel() {
    activityBtn?.classList.toggle('active', !!card);
  }

  async function openLocal(url, x, y) {
    if (card) return;
    await buildCard(url, x, y);
    updateActivityLabel();
  }

  activityBtn?.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (card) { destroy(); return; }
    const x = window.innerWidth / 2 - CARD_W / 2;
    const y = window.innerHeight / 2 - CARD_H / 2;
    await openLocal('https://www.google.com', x, y);
    window.Party.broadcast({
      t: 'bwOpen',
      url: 'https://www.google.com',
      x: x / window.innerWidth, y: y / window.innerHeight
    });
  });

  window.Party?.onMessage(async (fromId, m) => {
    if (m.t === 'bwOpen') {
      if (!card) {
        await openLocal(m.url, m.x * window.innerWidth, m.y * window.innerHeight);
        window.Party.sendTo(fromId, { t: 'bwVideoRequest' });
      }
    }
    else if (m.t === 'bwClose') {
      destroy();
    }
    else if (m.t === 'bwMove') {
      if (card && !dragging) setPos(m.x * window.innerWidth, m.y * window.innerHeight);
    }
    else if (m.t === 'bwNav') {
      if (webview) {
        applyingRemoteNav = true;
        webview.loadURL(m.url).catch(() => {});
        setTimeout(() => { applyingRemoteNav = false; }, 300);
      }
    }
    else if (m.t === 'bwScroll') {
      webview?.send('bw:apply-scroll', { x: m.x, y: m.y });
    }
    else if (m.t === 'bwSel') {
      webview?.send('bw:apply-selection', m.sel);
    }
    else if (m.t === 'bwVideo') {
      webview?.send('bw:apply-video', { action: m.action, t: m.t });
    }
    else if (m.t === 'bwVideoRequest') {
      webview?.send('bw:request-video-state');
    }
  });

  window.overlay.onRoster(({ members }) => {
    if (!members || members.length === 0) destroy();
  });

  window.BrowserActivity = {
    onPeerReady(peerId) {
      if (!card || !webview) return;
      const pos = currentPos();
      window.Party.sendTo(peerId, {
        t: 'bwOpen',
        url: webview.getURL() || 'https://www.google.com',
        x: pos.x / window.innerWidth,
        y: pos.y / window.innerHeight
      });
    }
  };
})();