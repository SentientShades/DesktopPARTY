const { ipcRenderer } = require('electron');

function xpathFor(node) {
  if (!node) return null;
  if (node.nodeType === Node.TEXT_NODE) {
    const parent = node.parentNode;
    const idx = Array.prototype.indexOf.call(parent.childNodes, node) + 1;
    return xpathFor(parent) + `/text()[${idx}]`;
  }
  if (node === document.body) return '/html/body';
  if (!node.parentNode) return '';
  let idx = 1;
  let sib = node.previousSibling;
  while (sib) {
    if (sib.nodeType === 1 && sib.tagName === node.tagName) idx++;
    sib = sib.previousSibling;
  }
  return xpathFor(node.parentNode) + `/${node.tagName.toLowerCase()}[${idx}]`;
}

function nodeFromXPath(xpath) {
  try {
    const r = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
    return r.singleNodeValue;
  } catch { return null; }
}

let applying = false;

document.addEventListener('scroll', () => {
  if (applying) return;
  ipcRenderer.sendToHost('bw:scroll', { x: window.scrollX, y: window.scrollY });
}, { passive: true, capture: true });

document.addEventListener('selectionchange', () => {
  if (applying) return;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0 || sel.isCollapsed) {
    ipcRenderer.sendToHost('bw:selection', null);
    return;
  }
  try {
    const range = sel.getRangeAt(0);
    ipcRenderer.sendToHost('bw:selection', {
      anchorPath: xpathFor(range.startContainer),
      anchorOffset: range.startOffset,
      focusPath: xpathFor(range.endContainer),
      focusOffset: range.endOffset,
      text: sel.toString().slice(0, 400)
    });
  } catch {}
});

ipcRenderer.on('bw:apply-scroll', (_e, { x, y }) => {
  applying = true;
  window.scrollTo(x, y);
  setTimeout(() => { applying = false; }, 50);
});

ipcRenderer.on('bw:apply-selection', (_e, sel) => {
  applying = true;
  try {
    const wsel = window.getSelection();
    wsel.removeAllRanges();
    if (sel) {
      const anchorNode = nodeFromXPath(sel.anchorPath);
      const focusNode = nodeFromXPath(sel.focusPath);
      if (anchorNode && focusNode) {
        const range = document.createRange();
        const aMax = anchorNode.length ?? anchorNode.childNodes.length;
        const fMax = focusNode.length ?? focusNode.childNodes.length;
        range.setStart(anchorNode, Math.min(sel.anchorOffset, aMax));
        range.setEnd(focusNode, Math.min(sel.focusOffset, fMax));
        wsel.addRange(range);
      }
    }
  } catch {}
  setTimeout(() => { applying = false; }, 50);
});

let applyingVideo = false;
const watchedVideos = new WeakSet();

function attachVideo(v) {
  if (watchedVideos.has(v)) return;
  watchedVideos.add(v);

  v.addEventListener('play', () => {
    if (applyingVideo) return;
    ipcRenderer.sendToHost('bw:video', { action: 'play', t: v.currentTime });
  });

  v.addEventListener('pause', () => {
    if (applyingVideo) return;
    ipcRenderer.sendToHost('bw:video', { action: 'pause', t: v.currentTime });
  });

  v.addEventListener('seeked', () => {
    if (applyingVideo) return;
    ipcRenderer.sendToHost('bw:video', { action: 'seek', t: v.currentTime });
  });
}

function scanVideos() {
  document.querySelectorAll('video').forEach(attachVideo);
}

scanVideos();
new MutationObserver(scanVideos).observe(document.documentElement, { childList: true, subtree: true });

ipcRenderer.on('bw:apply-video', (_e, { action, t }) => {
  const v = document.querySelector('video');
  if (!v) return;
  applyingVideo = true;

  if (Math.abs(v.currentTime - t) > 0.6) v.currentTime = t;
  if (action === 'play') v.play().catch(() => {});
  if (action === 'pause') v.pause();

  setTimeout(() => { applyingVideo = false; }, 150);
});

ipcRenderer.on('bw:request-video-state', () => {
  const v = document.querySelector('video');
  if (!v) return;
  ipcRenderer.sendToHost('bw:video', {
    action: v.paused ? 'pause' : 'play',
    t: v.currentTime
  });
});