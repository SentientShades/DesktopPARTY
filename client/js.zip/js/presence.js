const WebSocket = require('ws');

const PING_MS = 15000;
const MAX_BACKOFF = 30000;

let ws, sigWs;
let wsPing = null, sigPing = null;
let wsBackoff = 1000, sigBackoff = 1000;
let handlers = {};
let intentionalClose = false;

const signalQueue = [];
const outQueue = [];

function connect(userId, serverUrl, cbs = {}) {
  handlers = cbs;
  intentionalClose = false;

  ws = new WebSocket(`${serverUrl}/presence?userId=${encodeURIComponent(userId)}`, {
    headers: { 'ngrok-skip-browser-warning': 'true' }
  });

  ws.on('open', () => {
    console.log('presence connected');
    wsBackoff = 1000;
    outQueue.splice(0).forEach(m => ws.send(JSON.stringify(m)));

    clearInterval(wsPing);
    wsPing = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) ws.ping();
    }, PING_MS);
  });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {
      case 'party:roster': handlers.onRoster?.(msg); break;
      case 'error':         handlers.onError?.(msg); break;
    }
  });

  ws.on('close', () => {
    clearInterval(wsPing);
    if (intentionalClose) return;
    console.log(`presence closed, retrying in ${wsBackoff}ms`);
    setTimeout(() => connect(userId, serverUrl, handlers), wsBackoff);
    wsBackoff = Math.min(wsBackoff * 2, MAX_BACKOFF);
  });

  ws.on('error', (e) => console.error('presence error:', e.message));
}

function send(msg) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
  else outQueue.push(msg);
}

function connectSignal(userId, serverUrl, onSignal, onReady) {
  sigWs = new WebSocket(`${serverUrl}/signal?userId=${encodeURIComponent(userId)}`, {
    headers: { 'ngrok-skip-browser-warning': 'true' }
  });

  let firstOpen = true;

  sigWs.on('open', () => {
    console.log('signal connected');
    sigBackoff = 1000;
    const queued = signalQueue.splice(0);
    if (queued.length) console.log(`flushing ${queued.length} queued signal(s)`);
    queued.forEach(m => sigWs.send(JSON.stringify(m)));

    clearInterval(sigPing);
    sigPing = setInterval(() => {
      if (sigWs.readyState === WebSocket.OPEN) sigWs.ping();
    }, PING_MS);

    if (firstOpen) {
      firstOpen = false;
      onReady?.();
    }
  });

  sigWs.on('message', (raw) => {
    try { onSignal(JSON.parse(raw)); }
    catch (e) { console.warn('bad signal', e); }
  });

  sigWs.on('close', () => {
    clearInterval(sigPing);
    if (intentionalClose) return;
    setTimeout(() => connectSignal(userId, serverUrl, onSignal, null), sigBackoff);
    sigBackoff = Math.min(sigBackoff * 2, MAX_BACKOFF);
  });

  sigWs.on('error', (e) => console.error('signal error:', e.message));
}

function sendSignal(msg) {
  if (sigWs?.readyState === WebSocket.OPEN) sigWs.send(JSON.stringify(msg));
  else signalQueue.push(msg);
}

function disconnect() {
  intentionalClose = true;
  try { ws?.close(); } catch {}
  try { sigWs?.close(); } catch {}
  ws = null;
  sigWs = null;
  clearInterval(wsPing);
  clearInterval(sigPing);
  wsPing = null;
  sigPing = null;
  wsBackoff = 1000;
  sigBackoff = 1000;
  signalQueue.length = 0;
  outQueue.length = 0;
  handlers = {};
}

module.exports = { connect, send, connectSignal, sendSignal, disconnect };