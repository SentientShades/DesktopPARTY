(() => {
  const bar = document.createElement('div');
  bar.id = 'activity-status';
  bar.className = 'toast hidden';
  bar.innerHTML = `
    <div class="act-status-icon" id="act-status-icon">🎮</div>
    <div class="toast-body">
      <span class="toast-name" id="act-status-name"></span>
      <span class="toast-sub" id="act-status-line"></span>
    </div>
  `;
  document.body.appendChild(bar);
  window.StackLayout?.register(bar, { order: 1 });

  const iconEl = bar.querySelector('#act-status-icon');
  const nameEl = bar.querySelector('#act-status-name');
  const lineEl = bar.querySelector('#act-status-line');

  const ICONS = { UNO: '🎴', Browser: '🌐' };

  const producers = new Map();
  setInterval(tick, 500);

  function tick() {
    if (producers.size === 0) {
      bar.classList.add('hidden');
      window.StackLayout?.layout();
      return;
    }
    const fn = [...producers.values()][producers.size - 1];
    const { name, line } = fn();
    iconEl.textContent = ICONS[name] || '';
    nameEl.textContent = name;
    lineEl.textContent = line;
    bar.classList.remove('hidden');
    window.StackLayout?.layout();
  }

  function setStatus(fn) {
    const probe = fn();
    producers.set(probe.name, fn);
    tick();
  }
  function clearStatus(name) {
    producers.delete(name);
    tick();
  }
  function announce(activityId) {
    window.Toasts?.show({ name: 'Party', activity: `Activity started: ${activityId}`, status: 'online' });
  }

  window.Activity = { setStatus, clearStatus, announce };
})();