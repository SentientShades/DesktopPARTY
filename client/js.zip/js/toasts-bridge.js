let win = null;
let ready = false;
const pending = [];

function attach(browserWindow) {
  win = browserWindow;
  ready = false;
  win.webContents.on('did-finish-load', () => {
    ready = true;
    pending.splice(0).forEach(o => win.webContents.send('toast:show', o));
  });
}

function showToast(opts) {
  if (!win || win.isDestroyed()) return;
  if (!ready) { pending.push(opts); return; }
  win.webContents.send('toast:show', opts);
}

module.exports = { attach, showToast };