const { app, BrowserWindow, screen, ipcMain, dialog, nativeImage, Tray, Menu } = require('electron');
const path = require('path');
const { pathToFileURL } = require('url');
const toasts = require('./toasts-bridge');
const presence = require('./presence');
const store = require('./store');
const input = require('./input');
const activity = require('./activity');
const localserver = require('./localserver');
const tunnel = require('./tunnel');
const discord = require('./discord-rpc');

let launcherWin;
let win;
let tray = null;
let cursorTimer = null;
let userId = null;
let hosting = null;
let lastRosterMembers = [];
let partyStartedAt = 0;
let partyCode = null;

const sessionActive = () => !!userId || !!hosting;

function watchPreloadErrors(w) {
  w.webContents.on('preload-error', (_e, preloadPath, error) => {
    console.error('[preload error]', preloadPath, error);
    dialog.showErrorBox('Preload script failed', `${preloadPath}\n\n${error.message}\n\n${error.stack || ''}`);
  });
}

function forceFocus() {
  if (!win || win.isDestroyed()) return;
  win.setAlwaysOnTop(true, 'screen-saver');
  win.show();
  win.focus();
  win.moveTop();
}

function updateDiscordPresence(members) {
  const list = (members || []).filter(Boolean);
  const others = list.filter(id => id !== userId);
  const size = Math.max(1, list.length);

  if (!partyStartedAt) partyStartedAt = Date.now();

  const state = others.length === 0
    ? 'Just hanging out'
    : others.length <= 3
      ? `With ${others.join(', ')}`
      : `With ${others.slice(0, 2).join(', ')} +${others.length - 2} more`;

  discord.setActivity({
    details: hosting ? 'Hosting a party' : 'In a party',
    state,
    timestamps: { start: partyStartedAt },
    party: { id: partyCode || 'desktopparty', size: [size, 8] },
    assets: { large_image: 'party', large_text: 'DesktopPARTY!' },
    instance: false
  });
}

function trayIcon() {
  const p = store.getProfile();
  if (p.avatar) {
    try {
      return nativeImage.createFromDataURL(p.avatar).resize({ width: 16, height: 16 });
    } catch {}
  }
  return nativeImage.createFromPath(
    path.join(__dirname, '..', 'assets', 'appicon_512x512.ico')
  ).resize({ width: 16, height: 16 });
}

function ensureTray() {
  if (tray) return;
  tray = new Tray(trayIcon());
  tray.setToolTip('DesktopPARTY!');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open DesktopPARTY!', click: showLauncher },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]));
  tray.on('click', showLauncher);
}

function showLauncher() {
  if (launcherWin && !launcherWin.isDestroyed()) {
    launcherWin.show();
    launcherWin.focus();
  } else {
    createLauncher();
  }
}

function createLauncher() {
  launcherWin = new BrowserWindow({
    width: 440,
    height: 760,
    frame: false,
    resizable: false,
    backgroundColor: '#131313',
    icon: path.join(__dirname, '..', 'assets', 'appicon_512x512.ico'),
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  watchPreloadErrors(launcherWin);
  launcherWin.loadFile(path.join(__dirname, '..', 'html', 'launcher.html'));
  launcherWin.on('closed', () => { launcherWin = null; });
}

function createOverlay() {
  const { x, y, width, height } = screen.getPrimaryDisplay().workArea;

  win = new BrowserWindow({
    x, y, width, height,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    focusable: true,
    hasShadow: false,
    backgroundColor: '#00000000',
    icon: path.join(__dirname, '..', 'assets', 'appicon_512x512.ico'),
    webPreferences: {
      contextIsolation: true,
      webviewTag: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  watchPreloadErrors(win);
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setIgnoreMouseEvents(true, { forward: true });

  toasts.attach(win);
  win.loadFile(path.join(__dirname, '..', 'html', 'toast.html'));
  win.showInactive();

  win.on('closed', () => {
    clearInterval(cursorTimer);
    cursorTimer = null;
    win = null;
  });

  startCursorTracking();
}

function startCursorTracking() {
  const { width, height } = screen.getPrimaryDisplay().bounds;

  clearInterval(cursorTimer);
  cursorTimer = setInterval(() => {
    if (!win || win.isDestroyed()) return;
    const pt = screen.getCursorScreenPoint();
    win.webContents.send('cursor:local', { x: pt.x / width, y: pt.y / height });
  }, 16);
}

const toOverlay = (ch, p) => {
  if (win && !win.isDestroyed()) win.webContents.send(ch, p);
};
const toLauncher = (ch, p) => {
  if (launcherWin && !launcherWin.isDestroyed()) launcherWin.webContents.send(ch, p);
};

function applyClickCapture() {
  const { sendMyClicks } = store.getAll().settings;
  if (sendMyClicks && input.available.send) {
    const { width, height } = screen.getPrimaryDisplay().bounds;
    input.startClickCapture(({ rawX, rawY }) => {
      toOverlay('click:local', { x: rawX / width, y: rawY / height });
    });
  } else {
    input.stopClickCapture();
  }
}

app.whenReady().then(() => {
  discord.start();
  createLauncher();
});

ipcMain.handle('get-webview-preload-path', () => {
  return pathToFileURL(path.join(__dirname, 'browser-webview-preload.js')).toString();
});

ipcMain.handle('store:get', () => store.getAll());
ipcMain.handle('store:getProfile', () => store.getProfile());
ipcMain.handle('input:available', () => input.available);
ipcMain.handle('app:session', () => ({ active: sessionActive(), userId, hosting }));

ipcMain.handle('store:setProfile', (_e, patch) => {
  const p = store.setProfile(patch);
  toOverlay('profile:update', store.getProfile());
  if (tray) tray.setImage(trayIcon());
  return p;
});

ipcMain.handle('store:setSetting', (_e, { key, value }) => {
  const settings = store.setSetting(key, value);
  toOverlay('settings:update', settings);
  if (key === 'sendMyClicks') applyClickCapture();
  return settings;
});

ipcMain.handle('profile:pickAvatar', async () => {
  const res = await dialog.showOpenDialog(launcherWin, {
    title: 'Choose a profile picture',
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }],
    properties: ['openFile']
  });
  if (res.canceled || !res.filePaths[0]) return null;

  const img = nativeImage.createFromPath(res.filePaths[0]).resize({ width: 128, height: 128 });
  const dataUrl = img.toDataURL();

  store.setProfile({ avatar: dataUrl });
  toOverlay('profile:update', store.getProfile());
  if (tray) tray.setImage(trayIcon());
  return dataUrl;
});

ipcMain.handle('profile:pickCharacter', async () => {
  const res = await dialog.showOpenDialog(launcherWin, {
    title: 'Choose a character picture',
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }],
    properties: ['openFile']
  });
  if (res.canceled || !res.filePaths[0]) return null;

  const img = nativeImage.createFromPath(res.filePaths[0]).resize({ width: 96, height: 96 });
  const dataUrl = img.toDataURL();

  store.setProfile({ characterImage: dataUrl });
  toOverlay('profile:update', store.getProfile());
  return dataUrl;
});

ipcMain.handle('host:start', async () => {
  if (hosting) return hosting;
  try {
    const port = await localserver.start(8080);
    const { url, code } = await tunnel.start(port);
    hosting = { url, code };
    partyCode = code;
    store.setSetting('serverUrl', url);
    ensureTray();
    return hosting;
  } catch (e) {
    tunnel.stop();
    localserver.stop();
    hosting = null;
    throw new Error(e.message);
  }
});

ipcMain.handle('host:stop', () => {
  tunnel.stop();
  localserver.stop();
  hosting = null;
  return true;
});

ipcMain.handle('host:status', () => hosting);

ipcMain.handle('app:start', async (_e, { userId: id, serverUrl }) => {
  userId = String(id).trim();
  store.setUserId(userId);
  lastRosterMembers = [];
  partyStartedAt = 0;

  if (serverUrl) store.setSetting('serverUrl', serverUrl);
  const url = store.getAll().settings.serverUrl;

  if (!url) throw new Error('No server. Host a party or enter a code.');

  const codeMatch = /\/\/([a-z0-9-]+)\./i.exec(url);
  if (codeMatch) partyCode = codeMatch[1];

  if (!win || win.isDestroyed()) createOverlay();

  // signal socket must be OPEN before presence, or the roster broadcast
  // triggers offers that arrive before we can receive them
  await new Promise((resolve) => {
    let settled = false;
    const done = () => { if (!settled) { settled = true; resolve(); } };
    presence.connectSignal(userId, url, (msg) => toOverlay('signal:recv', msg), done);
    setTimeout(done, 4000);
  });

  presence.connect(userId, url, {
    onRoster: (msg) => {
      const newMembers = msg.members || [];
      const joined = newMembers.filter(id => id !== userId && !lastRosterMembers.includes(id));
      const left   = lastRosterMembers.filter(id => id !== userId && !newMembers.includes(id));

      joined.forEach(id => toasts.showToast({ id, name: id, activity: 'joined the party', status: 'online' }));
      left.forEach(id   => toasts.showToast({ id, name: id, activity: 'left the party', status: 'offline' }));

      lastRosterMembers = newMembers;
      updateDiscordPresence(newMembers);

      toOverlay('party:roster', { myId: userId, ...msg });
      toLauncher('party:roster', msg);
    },
    onError: (msg) => toLauncher('app:error', msg)
  });

  const boot = () => {
    toOverlay('peer:identity', { userId });
    toOverlay('settings:update', store.getAll().settings);
    toOverlay('profile:update', store.getProfile());
  };
  if (win.webContents.isLoading()) win.webContents.once('did-finish-load', boot);
  else boot();

  applyClickCapture();
  activity.start((a) => toOverlay('activity:local', a));
  updateDiscordPresence([userId]);

  ensureTray();
  return { ok: true, userId, serverUrl: url };
});

function endSession() {
  userId = null;
  lastRosterMembers = [];
  partyStartedAt = 0;
  partyCode = null;

  presence.disconnect();
  activity.stop();
  input.stopClickCapture();
  discord.clearActivity();

  if (win && !win.isDestroyed()) win.close();

  toLauncher('session:ended', {});
}

ipcMain.on('party:leave', () => {
  presence.send({ type: 'party:leave' });
  endSession();
});

ipcMain.on('draw:mode', (_e, active) => {
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(!active, { forward: true });
  if (active) forceFocus();
});

ipcMain.on('player:active', (_e, active) => {
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(!active, { forward: true });
  if (active) forceFocus();
});

ipcMain.on('request-focus', () => forceFocus());

ipcMain.on('set-ignore-mouse', (_e, ignore) => {
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(ignore, { forward: true });
});

ipcMain.on('click:remote', async (_e, { x, y }) => {
  if (!store.getAll().settings.allowRemoteClicks) return;
  const { width, height } = screen.getPrimaryDisplay().bounds;
  await input.injectClick(x * width, y * height);
});

ipcMain.on('app:minimize', () => launcherWin?.minimize());

ipcMain.on('app:close', () => {
  if (sessionActive()) {
    ensureTray();
    launcherWin?.hide();
  } else {
    launcherWin?.close();
  }
});

ipcMain.on('toast:clicked', (_e, id) => console.log('clicked toast', id));
ipcMain.on('signal:send', (_e, msg) => presence.sendSignal(msg));

function shutdown() {
  activity.stop();
  tunnel.stop();
  localserver.stop();
  input.stopClickCapture();
  discord.stop();
  tray?.destroy();
  tray = null;
}

app.on('before-quit', shutdown);

app.on('window-all-closed', () => {
  shutdown();
  if (process.platform !== 'darwin') app.quit();
});