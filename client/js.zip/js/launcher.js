const $ = (id) => document.getElementById(id);

let myId = null;
let mode = 'join';
let hostInfo = null;
let partyMembers = [];

const COLORS = ['#23d18b','#3a8ef0','#ffd24a','#e0508c','#9b6cf0','#22c8c8','#f06a3a','#c0c0c0'];

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return COLORS[h % COLORS.length];
}

function themeColor(p) {
  return p.accent || hashColor(p.userId || p.displayName || 'guest');
}

function applyAccent(hex) {
  document.documentElement.style.setProperty('--green', hex);
}

function setStatus(el, text, kind = '') {
  el.textContent = text;
  el.className = `status ${kind}`;
}

$('win-close').addEventListener('click', () => window.launcher.close());
$('win-min').addEventListener('click', () => window.launcher.minimize());

document.querySelectorAll('[data-close]').forEach(btn => {
  btn.addEventListener('click', () => $(btn.dataset.close).classList.add('hidden'));
});

$('open-settings').addEventListener('click', () => $('settings-sheet').classList.remove('hidden'));
$('open-profile').addEventListener('click', () => $('profile-sheet').classList.remove('hidden'));

function hslToHex(h, s, l) {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (h < 60)       { r = c; g = x; }
  else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; }
  else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; }
  else              { r = c; b = x; }
  const to = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0');
  return `#${to(r)}${to(g)}${to(b)}`;
}

function hexToHue(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  if (!m) return null;
  const [r, g, b] = m.slice(1).map(v => parseInt(v, 16) / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  if (!d) return 0;
  let h;
  if (max === r)      h = ((g - b) / d) % 6;
  else if (max === g) h = (b - r) / d + 2;
  else                h = (r - g) / d + 4;
  return Math.round(((h * 60) + 360) % 360);
}

function paintAccentPreview(hex) {
  $('accent-preview').style.setProperty('--accent-c', hex);
  $('accent-hue').style.setProperty('--thumb', hex);
}

function setMode(next) {
  mode = next;
  $('tab-join').classList.toggle('active', next === 'join');
  $('tab-host').classList.toggle('active', next === 'host');
  $('join-pane').classList.toggle('hidden', next !== 'join');
  $('host-pane').classList.toggle('hidden', next !== 'host');
}
$('tab-join').addEventListener('click', () => setMode('join'));
$('tab-host').addEventListener('click', () => setMode('host'));

$('host-btn').addEventListener('click', async () => {
  const btn = $('host-btn');
  btn.disabled = true;
  btn.textContent = 'Starting tunnel…';
  setStatus($('signin-status'), '');

  try {
    hostInfo = await window.launcher.hostStart();
    $('host-code').textContent = hostInfo.code;
    $('host-info').classList.remove('hidden');
    btn.textContent = 'Hosting';
    $('host-hint').textContent = 'Your party is live. Sign in below to join it.';
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'Start hosting';
    setStatus($('signin-status'), e.message, 'error');
  }
});

$('copy-code').addEventListener('click', () => {
  navigator.clipboard.writeText($('host-code').textContent);
  setStatus($('signin-status'), 'Code copied', 'ok');
});

$('banner-copy').addEventListener('click', () => {
  navigator.clipboard.writeText($('banner-code').textContent);
  setStatus($('status'), 'Code copied', 'ok');
});

function enterHome() {
  $('signin').classList.add('hidden');
  $('home').classList.remove('hidden');

  if (hostInfo) {
    $('banner-code').textContent = hostInfo.code;
    $('hosting-banner').classList.remove('hidden');
  }
}

async function signIn() {
  const userId = $('username').value.trim();
  if (!userId) return setStatus($('signin-status'), 'Enter a user ID first', 'error');

  let serverUrl = null;

  if (mode === 'host') {
    if (!hostInfo) return setStatus($('signin-status'), 'Start hosting first', 'error');
    serverUrl = hostInfo.url;
  } else {
    const code = $('join-code').value.trim();
    if (!code) return setStatus($('signin-status'), 'Enter a party code', 'error');
    serverUrl = code.startsWith('ws://') || code.startsWith('wss://')
      ? code
      : `wss://${code}.trycloudflare.com`;
  }

  $('go').disabled = true;
  setStatus($('signin-status'), 'Connecting…');

  try {
    await window.launcher.start({ userId, serverUrl });
    myId = userId;
    enterHome();
    await refreshProfile();
  } catch (e) {
    setStatus($('signin-status'), `Failed: ${e.message}`, 'error');
    $('go').disabled = false;
  }
}
$('go').addEventListener('click', signIn);
$('username').addEventListener('keydown', e => { if (e.key === 'Enter') signIn(); });
$('join-code').addEventListener('keydown', e => { if (e.key === 'Enter') signIn(); });

async function refreshProfile() {
  const p = await window.launcher.getProfile();
  $('me-name').textContent = p.displayName || p.userId;
  $('display-name').value = p.displayName || '';

  if (p.avatar) {
    $('me-avatar').style.backgroundImage = `url('${p.avatar}')`;
    $('avatar-preview').style.backgroundImage = `url('${p.avatar}')`;
    $('brand-avatar').style.backgroundImage = `url('${p.avatar}')`;
    $('brand-avatar').classList.add('has-avatar');
  }

  if (p.characterImage) {
    $('character-preview').style.backgroundImage = `url('${p.characterImage}')`;
  } else {
    $('character-preview').style.backgroundImage = '';
  }

  const hue = hexToHue(p.accent);
  if (hue !== null) $('accent-hue').value = hue;

  const hex = themeColor(p);
  paintAccentPreview(hex);
  applyAccent(hex);
}

$('pick-avatar').addEventListener('click', async () => {
  const dataUrl = await window.launcher.pickAvatar();
  if (!dataUrl) return;
  $('avatar-preview').style.backgroundImage = `url('${dataUrl}')`;
  $('me-avatar').style.backgroundImage = `url('${dataUrl}')`;
  $('brand-avatar').style.backgroundImage = `url('${dataUrl}')`;
  $('brand-avatar').classList.add('has-avatar');
  setStatus($('profile-status'), 'Picture updated', 'ok');
});

$('pick-character').addEventListener('click', async () => {
  const dataUrl = await window.launcher.pickCharacter();
  if (!dataUrl) return;
  $('character-preview').style.backgroundImage = `url('${dataUrl}')`;
  setStatus($('profile-status'), 'Character picture updated', 'ok');
});

$('clear-character').addEventListener('click', async () => {
  await window.launcher.setProfile({ characterImage: '' });
  $('character-preview').style.backgroundImage = '';
  setStatus($('profile-status'), 'Character back to solid color', 'ok');
});

$('accent-hue').addEventListener('input', () => {
  const hex = hslToHex(Number($('accent-hue').value), 0.85, 0.5);
  paintAccentPreview(hex);
  applyAccent(hex);
  window.launcher.setProfile({ accent: hex });
});

$('accent-reset').addEventListener('click', async () => {
  await window.launcher.setProfile({ accent: '' });
  await refreshProfile();
  setStatus($('profile-status'), 'Using automatic colour', 'ok');
});

$('save-profile').addEventListener('click', async () => {
  await window.launcher.setProfile({ displayName: $('display-name').value.trim() });
  await refreshProfile();
  setStatus($('profile-status'), 'Saved', 'ok');
});

$('leave-party').addEventListener('click', () => window.launcher.leaveParty());

function renderParty() {
  const list = $('party-list');
  list.innerHTML = '';
  list.classList.toggle('is-empty', partyMembers.length === 0);
  $('party-count').textContent = `${partyMembers.length}/8`;
  $('leave-party').disabled = partyMembers.length === 0;

  partyMembers.forEach(name => {
    const row = document.createElement('div');
    row.className = 'item';

    const av = document.createElement('span');
    av.className = 'avatar-sm online';
    av.style.borderColor = name === myId ? themeColor({ userId: myId }) : hashColor(name);

    const nm = document.createElement('span');
    nm.className = 'item-name';
    nm.textContent = name;

    row.append(av, nm);
    if (name === myId) {
      const you = document.createElement('span');
      you.className = 'you-tag';
      you.textContent = 'you';
      row.appendChild(you);
    }
    list.appendChild(row);
  });
}

window.launcher.onRoster(r => {
  partyMembers = r.members || [];
  renderParty();
});

window.launcher.onError(m => setStatus($('status'), m.message, 'error'));

window.launcher.onSessionEnded(() => {
  myId = null;
  hostInfo = null;
  partyMembers = [];

  $('home').classList.add('hidden');
  $('hosting-banner').classList.add('hidden');
  $('host-info').classList.add('hidden');
  $('host-btn').disabled = false;
  $('host-btn').textContent = 'Start hosting';
  $('go').disabled = false;

  $('signin').classList.remove('hidden');
  setStatus($('signin-status'), 'Left the party', 'ok');
  $('username').focus();
});

async function initSettings() {
  const store = await window.launcher.getStore();
  const avail = await window.launcher.inputAvailable();

  ['showNames', 'allowDrawing', 'sendMyClicks', 'allowRemoteClicks'].forEach(key => {
    const el = $(`set-${key}`);
    el.checked = !!store.settings[key];
    el.addEventListener('change', () => window.launcher.setSetting(key, el.checked));
  });

  const serverInput = $('set-serverUrl');
  serverInput.value = store.settings.serverUrl || '';
  serverInput.addEventListener('change', () => {
    window.launcher.setSetting('serverUrl', serverInput.value.trim());
  });

  if (!avail.send) $('set-sendMyClicks').disabled = true;
  if (!avail.receive) $('set-allowRemoteClicks').disabled = true;
  if (!avail.send || !avail.receive) {
    $('input-warn').textContent =
      'Remote input needs native modules. Run: npm i uiohook-napi @nut-tree-fork/nut-js';
  }
}

async function boot() {
  const store = await window.launcher.getStore();

  if (store.userId) $('username').value = store.userId;

  const p = await window.launcher.getProfile();
  applyAccent(themeColor(p));
  if (p.avatar) {
    $('brand-avatar').style.backgroundImage = `url('${p.avatar}')`;
    $('brand-avatar').classList.add('has-avatar');
  }

  const sess = await window.launcher.session();
  if (sess.active && sess.userId) {
    myId = sess.userId;
    hostInfo = sess.hosting || null;
    enterHome();
    await refreshProfile();
  } else {
    $('username').focus();
  }

  initSettings();
}

boot();