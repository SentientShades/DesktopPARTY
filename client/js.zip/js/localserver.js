const http = require('http');
const { WebSocketServer } = require('ws');

const MAX_PARTY = 8;

let server = null;
let wss = null;
let pingTimer = null;
let mainPartyId = null;

const clients = new Map();
const signalClients = new Map();
const pendingSignals = new Map();
const parties = new Map();
const userParty = new Map();

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function newPartyId() {
  return Math.random().toString(36).slice(2, 10);
}

function rosterOf(partyId) {
  const members = parties.get(partyId);
  return {
    type: 'party:roster',
    partyId: members ? partyId : null,
    members: members ? [...members].sort() : []
  };
}

function broadcastRoster(partyId) {
  const members = parties.get(partyId);
  if (!members) return;
  const payload = rosterOf(partyId);
  members.forEach(id => send(clients.get(id), payload));
}

function autoJoin(userId) {
  if (!mainPartyId || !parties.has(mainPartyId)) {
    mainPartyId = newPartyId();
    parties.set(mainPartyId, new Set());
  }

  const members = parties.get(mainPartyId);
  if (members.size >= MAX_PARTY) {
    send(clients.get(userId), { type: 'error', message: `Party is full (${MAX_PARTY} max)` });
    return;
  }

  members.add(userId);
  userParty.set(userId, mainPartyId);
  console.log(`[host] auto-joined: ${userId} -> ${mainPartyId} (${members.size}/${MAX_PARTY})`);
  broadcastRoster(mainPartyId);
}

function leaveParty(userId) {
  const partyId = userParty.get(userId);
  if (!partyId) return;
  userParty.delete(userId);

  const members = parties.get(partyId);
  if (members) {
    members.delete(userId);
    if (members.size === 0) {
      parties.delete(partyId);
      if (mainPartyId === partyId) mainPartyId = null;
      console.log(`[host] party disbanded: ${partyId}`);
    } else {
      broadcastRoster(partyId);
    }
  }
  send(clients.get(userId), { type: 'party:roster', partyId: null, members: [] });
}

function handlePresence(ws, userId) {
  clients.set(userId, ws);
  console.log(`[host] presence connect: ${userId} (${clients.size} online)`);
  autoJoin(userId);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (msg.type === 'party:leave') leaveParty(userId);
  });

  ws.on('close', () => {
    if (clients.get(userId) === ws) {
      clients.delete(userId);
      leaveParty(userId);
      console.log(`[host] presence close: ${userId}`);
    }
  });

  ws.on('error', (e) => console.log('[host] presence error:', e.message));
}

function handleSignal(ws, userId) {
  signalClients.set(userId, ws);
  console.log(`[host] signal connect: ${userId}`);

  const queued = pendingSignals.get(userId);
  if (queued?.length) {
    console.log(`[host] flushing ${queued.length} queued signal(s) to ${userId}`);
    queued.forEach(msg => send(ws, msg));
    pendingSignals.delete(userId);
  }

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!msg.to) return;

    msg.from = userId;
    const target = signalClients.get(msg.to);

    if (target) {
      console.log(`[host] signal ${msg.type}: ${userId} -> ${msg.to}  OK`);
      send(target, msg);
    } else {
      console.log(`[host] signal ${msg.type}: ${userId} -> ${msg.to}  QUEUED`);
      if (!pendingSignals.has(msg.to)) pendingSignals.set(msg.to, []);
      const q = pendingSignals.get(msg.to);
      q.push(msg);
      if (q.length > 50) q.shift();
    }
  });

  ws.on('close', () => {
    if (signalClients.get(userId) === ws) {
      signalClients.delete(userId);
      console.log(`[host] signal close: ${userId}`);
    }
  });

  ws.on('error', (e) => console.log('[host] signal error:', e.message));
}

function start(port = 8080) {
  return new Promise((resolve, reject) => {
    if (server) return resolve(port);

    server = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('DesktopFriends host\n');
    });

    wss = new WebSocketServer({ noServer: true });

    server.on('upgrade', (req, socket, head) => {
      let url;
      try { url = new URL(req.url, 'http://localhost'); }
      catch { return socket.destroy(); }

      const userId = url.searchParams.get('userId');
      if (!userId) return socket.destroy();

      wss.handleUpgrade(req, socket, head, (ws) => {
        if (url.pathname === '/presence') handlePresence(ws, userId);
        else if (url.pathname === '/signal') handleSignal(ws, userId);
        else ws.close();
      });
    });

    pingTimer = setInterval(() => {
      wss?.clients.forEach(c => { if (c.readyState === 1) c.ping(); });
    }, 15000);

    server.once('error', (e) => {
      clearInterval(pingTimer);
      server = null;
      wss = null;
      reject(new Error(
        e.code === 'EADDRINUSE' ? `Port ${port} is already in use` : e.message
      ));
    });

    server.listen(port, () => {
      console.log(`[host] listening on ${port}`);
      resolve(port);
    });
  });
}

function stop() {
  clearInterval(pingTimer);
  pingTimer = null;

  try { wss?.clients.forEach(c => c.close()); } catch {}
  try { wss?.close(); } catch {}
  try { server?.close(); } catch {}

  server = null;
  wss = null;
  mainPartyId = null;
  clients.clear();
  signalClients.clear();
  pendingSignals.clear();
  parties.clear();
  userParty.clear();
  console.log('[host] stopped');
}

module.exports = { start, stop, isRunning: () => !!server };