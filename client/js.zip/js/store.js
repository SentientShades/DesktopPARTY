const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const dir  = app.getPath('userData');
const file = path.join(dir, 'desktopfriends.json');
const tmpFile = file + '.tmp';

const DEFAULTS = {
  userId: '',
  profile: { displayName: '', avatar: '', accent: '', characterImage: '' },
  settings: {
    showNames: true,
    allowRemoteClicks: false,
    allowDrawing: true,
    sendMyClicks: false,
    serverUrl: ''
  }
};

let data = structuredClone(DEFAULTS);

function load() {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const p = JSON.parse(raw);
    data = {
      ...structuredClone(DEFAULTS), ...p,
      profile:  { ...DEFAULTS.profile,  ...(p.profile  || {}) },
      settings: { ...DEFAULTS.settings, ...(p.settings || {}) }
    };
  } catch (e) {
    if (e.code !== 'ENOENT') {
      console.error('[store] corrupt save file, backing up:', e.message);
      try { fs.copyFileSync(file, file + `.corrupt-${Date.now()}.bak`); } catch {}
    }
    data = structuredClone(DEFAULTS);
  }
  return data;
}

function save() {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2));
    fs.renameSync(tmpFile, file);
  } catch (e) {
    console.error('store save failed:', e.message);
  }
}

const getAll = () => data;

const getProfile = () => ({
  userId: data.userId,
  displayName: data.profile.displayName || data.userId,
  avatar: data.profile.avatar || '',
  accent: data.profile.accent || '',
  characterImage: data.profile.characterImage || ''
});

function setUserId(id) { data.userId = id; save(); }

function setProfile(patch) {
  data.profile = { ...data.profile, ...patch };
  save();
  return data.profile;
}

function setSetting(key, value) {
  if (!(key in DEFAULTS.settings)) return data.settings;
  data.settings[key] = value;
  save();
  return data.settings;
}

load();

module.exports = { getAll, getProfile, setUserId, setProfile, setSetting, file };