const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('overlay', {
  setIgnoreMouse: (ignore) => ipcRenderer.send('set-ignore-mouse', ignore),
  drawMode:       (active) => ipcRenderer.send('draw:mode', active),
  playerActive:   (active) => ipcRenderer.send('player:active', active),
  requestFocus:   ()       => ipcRenderer.send('request-focus'),

  getWebviewPreloadPath: () => ipcRenderer.invoke('get-webview-preload-path'),

  onToast:       (h)   => ipcRenderer.on('toast:show', (_e, o) => h(o)),
  onToastClick:  (id)  => ipcRenderer.send('toast:clicked', id),

  signal:        (msg) => ipcRenderer.send('signal:send', msg),
  onSignal:      (h)   => ipcRenderer.on('signal:recv', (_e, m) => h(m)),

  onLocalCursor: (h)   => ipcRenderer.on('cursor:local', (_e, p) => h(p)),
  onLocalClick:  (h)   => ipcRenderer.on('click:local', (_e, p) => h(p)),
  onActivity:    (h)   => ipcRenderer.on('activity:local', (_e, a) => h(a)),
  remoteClick:   (p)   => ipcRenderer.send('click:remote', p),

  onIdentity:    (h)   => ipcRenderer.on('peer:identity', (_e, i) => h(i)),
  onRoster:      (h)   => ipcRenderer.on('party:roster', (_e, r) => h(r)),
  onSettings:    (h)   => ipcRenderer.on('settings:update', (_e, s) => h(s)),
  onProfile:     (h)   => ipcRenderer.on('profile:update', (_e, p) => h(p))
});

contextBridge.exposeInMainWorld('launcher', {
  start:          (o) => ipcRenderer.invoke('app:start', o),
  session:        ()  => ipcRenderer.invoke('app:session'),
  close:          ()  => ipcRenderer.send('app:close'),
  minimize:       ()  => ipcRenderer.send('app:minimize'),

  getStore:       ()  => ipcRenderer.invoke('store:get'),
  inputAvailable: ()  => ipcRenderer.invoke('input:available'),

  getProfile:     ()      => ipcRenderer.invoke('store:getProfile'),
  setProfile:     (patch) => ipcRenderer.invoke('store:setProfile', patch),
  pickAvatar:     ()      => ipcRenderer.invoke('profile:pickAvatar'),
  pickCharacter:  ()      => ipcRenderer.invoke('profile:pickCharacter'),
  setSetting:     (key, value) => ipcRenderer.invoke('store:setSetting', { key, value }),

  hostStart:      () => ipcRenderer.invoke('host:start'),
  hostStop:       () => ipcRenderer.invoke('host:stop'),
  hostStatus:     () => ipcRenderer.invoke('host:status'),

  leaveParty:     ()  => ipcRenderer.send('party:leave'),

  onRoster:        (h) => ipcRenderer.on('party:roster', (_e, r) => h(r)),
  onError:         (h) => ipcRenderer.on('app:error', (_e, m) => h(m)),
  onSessionEnded:  (h) => ipcRenderer.on('session:ended', () => h())
});