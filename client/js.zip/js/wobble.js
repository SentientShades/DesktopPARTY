(() => {
  const BORDER_SELECTOR = [
    '.toast:not(.entering):not(.leaving)', '.list', '.host-info',
    '.banner', '.modal-box', '.party-drop', '.me-bar',
    '.avatar-preview', '.brand-mark'
  ].join(', ');

  const TEXT_SELECTOR = [
    '.tool', '.toggle', '.custom-swatch', '.accent-preview',
    '.avatar-sm', '.me-avatar', '.pd-av', '.pp-face',
    'input[type="text"]', 'button', '.pill'
  ].join(', ');

  const FLIP_MS = 220;
  const N_FILTERS = 10;
  const MAX_OFFSET_BORDER = 0.5;
  const MAX_OFFSET_TEXT   = 0.5;
  const SCAN_DEBOUNCE_MS  = 300;

  function buildFilterBank(prefix, scaleRange, freqRange) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.style.position = 'absolute';
    svg.style.pointerEvents = 'none';

    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');

    for (let i = 0; i < N_FILTERS; i++) {
      const filter = document.createElementNS('http://www.w3.org/2000/svg', 'filter');
      filter.setAttribute('id', `${prefix}-${i}`);
      filter.setAttribute('x', '-10%');
      filter.setAttribute('y', '-10%');
      filter.setAttribute('width', '120%');
      filter.setAttribute('height', '120%');

      const turb = document.createElementNS('http://www.w3.org/2000/svg', 'feTurbulence');
      turb.setAttribute('type', 'fractalNoise');
      turb.setAttribute('baseFrequency', (freqRange[0] + Math.random() * (freqRange[1] - freqRange[0])).toFixed(4));
      turb.setAttribute('numOctaves', '2');
      turb.setAttribute('seed', String(i * 7 + 1));
      turb.setAttribute('result', 'noise');

      const disp = document.createElementNS('http://www.w3.org/2000/svg', 'feDisplacementMap');
      disp.setAttribute('in', 'SourceGraphic');
      disp.setAttribute('in2', 'noise');
      disp.setAttribute('scale', String(scaleRange[0] + Math.random() * (scaleRange[1] - scaleRange[0])));
      disp.setAttribute('xChannelSelector', 'R');
      disp.setAttribute('yChannelSelector', 'G');

      filter.append(turb, disp);
      defs.appendChild(filter);
    }

    svg.appendChild(defs);
    document.body.appendChild(svg);
  }

  buildFilterBank('squiggly-border', [1, 2.2], [0.008, 0.014]);
  buildFilterBank('squiggly-text', [0.3, 0.7], [0.006, 0.01]);

  const items = [];

  function randFilterIndex(excluding) {
    let i = Math.floor(Math.random() * N_FILTERS);
    if (N_FILTERS > 1) {
      while (i === excluding) i = Math.floor(Math.random() * N_FILTERS);
    }
    return i;
  }

  function randOffset(max) {
    const ang = Math.random() * Math.PI * 2;
    const r = Math.random() * max;
    return { x: Math.cos(ang) * r, y: Math.sin(ang) * r };
  }

  function register(el, kind) {
    if (el.__wobbled) return;
    el.__wobbled = true;

    const prefix = kind === 'border' ? 'squiggly-border' : 'squiggly-text';
    const maxOffset = kind === 'border' ? MAX_OFFSET_BORDER : MAX_OFFSET_TEXT;

    const current = randFilterIndex(-1);
    items.push({
      el,
      prefix,
      maxOffset,
      currentIndex: current,
      offset: Math.random() * FLIP_MS,
      lastFlip: 0
    });
    el.style.filter = `url(#${prefix}-${current})`;
  }

  function scan() {
    // never register anything while a player is mid-drag — avoids doing
    // querySelectorAll work on the exact frames drag input needs to land
    if (window.__playerDragging) return;
    document.querySelectorAll(BORDER_SELECTOR).forEach(el => register(el, 'border'));
    document.querySelectorAll(TEXT_SELECTOR).forEach(el => register(el, 'text'));
  }

  let scanTimer = null;
  function debouncedScan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, SCAN_DEBOUNCE_MS);
  }

  function tick(now) {
    // freeze all wobble updates while any player drag is happening —
    // frees the main thread to prioritize pointermove handling
    if (!window.__playerDragging) {
      for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i];
        if (!document.body.contains(item.el)) { items.splice(i, 1); continue; }

        const cycle = Math.floor((now + item.offset) / FLIP_MS);
        if (cycle !== item.lastFlip) {
          item.lastFlip = cycle;
          item.currentIndex = randFilterIndex(item.currentIndex);
          item.el.style.filter = `url(#${item.prefix}-${item.currentIndex})`;

          const off = randOffset(item.maxOffset);
          item.el.style.translate = `${off.x.toFixed(2)}px ${off.y.toFixed(2)}px`;
        }
      }
    }
    requestAnimationFrame(tick);
  }

  const mo = new MutationObserver(debouncedScan);
  mo.observe(document.body, { childList: true, subtree: true });

  scan();
  requestAnimationFrame(tick);
})();