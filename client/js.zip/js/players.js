(() => {
  const PLAYER_W = 34;
  const PLAYER_H = 52;
  const OFFSCREEN_MARGIN = 60;
  const BROADCAST_MS = 50;

  const world = document.createElement('div');
  world.id = 'player-world';
  document.body.appendChild(world);

  const players = new Map();
  let myId = null;

  const keys = { a: false, d: false, w: false };
  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'a' || k === 'd' || k === 'w') keys[k] = true;
  });
  window.addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'a' || k === 'd' || k === 'w') keys[k] = false;
  });

  function updateHasPlayers() {
    window.__hasPlayers = players.size > 0 || (window.PhysicsObjects?.count() > 0);
  }

  const nameOf = (id) => window.Party?.infoFor?.(id)?.name || id;
  const characterOf = (id) => window.Party?.infoFor?.(id)?.characterImage || '';

  function applyLook(el, color, characterImage) {
    el.style.setProperty('--player-color', color);
    if (characterImage) {
      el.style.backgroundImage = `url('${characterImage}')`;
      el.classList.add('has-character');
    } else {
      el.style.backgroundImage = '';
      el.classList.remove('has-character');
    }
  }

  function makePlayer(id, color, owner, characterImage, x, y) {
    const wrap = document.createElement('div');
    wrap.className = 'player-wrap';

    const tag = document.createElement('span');
    tag.className = 'player-tag';
    tag.textContent = nameOf(id);
    tag.style.setProperty('--player-color', color);

    const el = document.createElement('div');
    el.className = 'player interactive';
    el.style.width = PLAYER_W + 'px';
    el.style.height = PLAYER_H + 'px';
    applyLook(el, color, characterImage || characterOf(id));

    wrap.append(tag, el);
    world.appendChild(wrap);

    const p = {
      id, el, wrap, owner,
      hw: PLAYER_W / 2, hh: PLAYER_H / 2,
      body: null,
      dragging: false,
      constraint: null,
      lastGroundedAt: 0,
      lastTouchAt: 0,
      history: []
    };

    players.set(id, p);
    window.PhysicsObjects?.attachPlayerBody?.(p, x, y);
    render(p);
    updateHasPlayers();
    return p;
  }

  function render(p) {
    if (!p.body) return;
    const pos = p.body.position;
    p.wrap.style.transform = `translate(${(pos.x - p.hw).toFixed(1)}px, ${(pos.y - p.hh).toFixed(1)}px)`;
    p.el.style.transform = `rotate(${(p.body.angle * 180 / Math.PI).toFixed(2)}deg)`;
  }

  function despawn(id, silent) {
    const p = players.get(id);
    if (!p) return;
    window.PhysicsObjects?.detachPlayerBody?.(p);
    p.wrap.remove();
    players.delete(id);
    updateHasPlayers();
    if (id === myId && !silent) window.Party.broadcast({ t: 'pld' });
  }

  let lastBroadcast = 0;
  function broadcastTick(now) {
    const me = myId && players.get(myId);
    if (me?.body && now - lastBroadcast > BROADCAST_MS) {
      lastBroadcast = now;
      const pos = me.body.position, v = me.body.velocity;
      window.Party.broadcast({
        t: 'plu',
        x: pos.x / window.innerWidth, y: pos.y / window.innerHeight,
        vx: v.x, vy: v.y,
        rot: me.body.angle, w: me.body.angularVelocity
      });
    }
    requestAnimationFrame(broadcastTick);
  }
  requestAnimationFrame(broadcastTick);

  const SPAWN_THRESHOLD = 90;

  function bindMeRow() {
    const row = document.getElementById('pd-row-me');
    if (!row || row.__bound) return;
    row.__bound = true;

    let dragging = false, armed = true, origin = null, spawned = null;

    row.addEventListener('pointerdown', (e) => {
      dragging = true; armed = true; spawned = null;
      origin = { x: e.clientX, y: e.clientY };
      window.__spawnDragging = true;
      try { row.setPointerCapture(e.pointerId); } catch {}
      row.classList.add('pd-dragging');
    });

    row.addEventListener('pointermove', (e) => {
      if (!dragging) return;

      if (armed) {
        const dx = e.clientX - origin.x, dy = e.clientY - origin.y;
        const dist = Math.hypot(dx, dy);

        if (dist >= SPAWN_THRESHOLD) {
          armed = false;
          row.classList.remove('pd-dragging', 'pd-ready');
          row.style.transform = '';

          despawn(myId, true);
          const color = window.Party.colorFor(myId);
          const characterImage = window.Party.infoFor(myId).characterImage || '';
          spawned = makePlayer(myId, color, true, characterImage, e.clientX, e.clientY);

          window.Party.broadcast({
            t: 'pls',
            x: e.clientX / window.innerWidth, y: e.clientY / window.innerHeight,
            color, characterImage
          });

          window.PhysicsObjects?.beginPlayerDrag?.(spawned, e.clientX, e.clientY);
          return;
        }

        const resisted = Math.min(Math.sqrt(dist) * 4, 70);
        const ang = Math.atan2(dy, dx);
        row.style.transform = `translate(${Math.cos(ang) * resisted}px, ${Math.sin(ang) * resisted}px)`;
        row.classList.toggle('pd-ready', dist > SPAWN_THRESHOLD * 0.85);
        return;
      }

      if (spawned) window.PhysicsObjects?.movePlayerDrag?.(spawned, e.clientX, e.clientY);
    });

    const end = (e) => {
      if (!dragging) return;
      dragging = false;
      window.__spawnDragging = false;

      if (armed) {
        row.classList.remove('pd-dragging', 'pd-ready');
        row.style.transform = '';
        return;
      }
      if (spawned) {
        window.PhysicsObjects?.endPlayerDrag?.(spawned, e.clientX, e.clientY);
        spawned = null;
      }
    };
    row.addEventListener('pointerup', end);
    row.addEventListener('pointercancel', end);
  }

  document.addEventListener('pd:rendered', bindMeRow);

  window.Party?.onMessage((fromId, m) => {
    if (m.t === 'pls') {
      despawn(fromId, true);
      makePlayer(
        fromId,
        m.color || window.Party.colorFor(fromId),
        false,
        m.characterImage || '',
        m.x * window.innerWidth,
        m.y * window.innerHeight
      );
    }
    else if (m.t === 'pld') despawn(fromId, true);
    else if (m.t === 'plu') {
      const p = players.get(fromId);
      if (!p || p.owner || !p.body) return;
      window.PhysicsObjects?.applyRemotePlayerState?.(p, m);
    }
  });

  window.overlay.onIdentity(({ userId }) => { myId = userId; });

  window.overlay.onProfile(() => {
    const p = players.get(myId);
    if (!p) return;
    applyLook(p.el, window.Party.colorFor(myId), characterOf(myId));
  });

  window.overlay.onRoster(({ members }) => {
    const set = new Set(members || []);
    players.forEach((p, id) => { if (id !== myId && !set.has(id)) despawn(id, true); });
  });

  window.Players = {
    despawn,
    updateHasPlayers,
    render,
    keys,
    myId: () => myId,
    all: () => players,

    getBodies() {
      const out = [];
      players.forEach(p => { if (p.body) out.push(p); });
      return out;
    },

    checkThrowKill(p, clientX, clientY) {
      if (p.dragging) return false;
      const off =
        clientX < -OFFSCREEN_MARGIN || clientX > window.innerWidth + OFFSCREEN_MARGIN ||
        clientY < -OFFSCREEN_MARGIN || clientY > window.innerHeight + OFFSCREEN_MARGIN;
      if (off) {
        despawn(p.id, !p.owner);
        if (p.owner) window.overlay.playerActive?.(false);
        return true;
      }
      return false;
    }
  };
})();