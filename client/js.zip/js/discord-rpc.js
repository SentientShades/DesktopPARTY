const net = require('net');
const os = require('os');

const OP = { HANDSHAKE: 0, FRAME: 1, CLOSE: 2, PING: 3, PONG: 4 };

// ← paste your Discord Application ID here
const CLIENT_ID = '1541222990224687184';

let socket = null;
let connected = false;
let reconnectTimer = null;
let pendingActivity = null;
let nonce = 0;

function pipePath(n) {
  return process.platform === 'win32'
    ? `\\\\.\\pipe\\discord-ipc-${n}`
    : `${process.env.XDG_RUNTIME_DIR || process.env.TMPDIR || os.tmpdir()}/discord-ipc-${n}`;
}

function encode(op, data) {
  const json = Buffer.from(JSON.stringify(data), 'utf8');
  const header = Buffer.alloc(8);
  header.writeInt32LE(op, 0);
  header.writeInt32LE(json.length, 4);
  return Buffer.concat([header, json]);
}

function tryConnect(n = 0) {
  if (n > 9) {
    scheduleReconnect();
    return;
  }

  const sock = net.createConnection(pipePath(n));
  let buf = Buffer.alloc(0);

  sock.on('connect', () => {
    socket = sock;
    sock.write(encode(OP.HANDSHAKE, { v: 1, client_id: CLIENT_ID }));
  });

  sock.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 8) {
      const op = buf.readInt32LE(0);
      const len = buf.readInt32LE(4);
      if (buf.length < 8 + len) break;

      const body = buf.subarray(8, 8 + len).toString('utf8');
      buf = buf.subarray(8 + len);

      let payload;
      try { payload = JSON.parse(body); } catch { continue; }

      if (op === OP.PING) {
        sock.write(encode(OP.PONG, payload));
      } else if (payload.evt === 'READY') {
        connected = true;
        console.log('[discord] connected as', payload.data?.user?.username || 'unknown');
        if (pendingActivity) setActivity(pendingActivity);
      } else if (payload.evt === 'ERROR') {
        console.log('[discord] error:', payload.data?.message);
      }
    }
  });

  sock.on('error', () => {
    sock.destroy();
    if (socket === sock) { socket = null; connected = false; }
    tryConnect(n + 1);
  });

  sock.on('close', () => {
    if (socket === sock) {
      socket = null;
      connected = false;
      scheduleReconnect();
    }
  });
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(() => tryConnect(0), 15000);
}

function setActivity(activity) {
  pendingActivity = activity;
  if (!connected || !socket) return;

  try {
    socket.write(encode(OP.FRAME, {
      cmd: 'SET_ACTIVITY',
      args: { pid: process.pid, activity },
      nonce: String(++nonce)
    }));
  } catch (e) {
    console.log('[discord] write failed:', e.message);
  }
}

function clearActivity() {
  pendingActivity = null;
  if (!connected || !socket) return;
  try {
    socket.write(encode(OP.FRAME, {
      cmd: 'SET_ACTIVITY',
      args: { pid: process.pid, activity: null },
      nonce: String(++nonce)
    }));
  } catch {}
}

function start() {
  if (!CLIENT_ID || CLIENT_ID.startsWith('0000')) {
    console.log('[discord] no CLIENT_ID set — rich presence disabled');
    return;
  }
  tryConnect(0);
}

function stop() {
  clearTimeout(reconnectTimer);
  clearActivity();
  try { socket?.destroy(); } catch {}
  socket = null;
  connected = false;
}

module.exports = { start, setActivity, clearActivity, stop };