let ignoring = true;

function setIgnore(next) {
  if (next === ignoring) return;
  ignoring = next;
  window.overlay.setIgnoreMouse(next);
}

window.addEventListener('mousemove', (e) => {
  // holding a weapon keeps the overlay live so aiming and firing work
  if (window.__drawMode || window.__hasPlayers || window.__weaponActive) {
    setIgnore(false);
    return;
  }

  const el = document.elementFromPoint(e.clientX, e.clientY);
  const overUI = !!el && el.closest('.interactive') !== null;
  setIgnore(!overUI);
});